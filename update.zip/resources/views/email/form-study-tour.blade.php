Nama Lengkap : {{$email->nama_lengkap}} <br>
Tanggal Lahir : {{$email->tanggal_lahir.'/'.$email->bulan_lahir.'/'.$email->tahun_lahir}} <br>
Alamat : {{$email->alamat}} 