 <h3> Auto reply – Translate Dokumen </h3>
 Hi {{$email->nama}}, <br>
 Terima kasih telah mendaftar dan mengupload dokumen untuk diterjemahkan. Kami akan menghubungi anda kembali untuk mengkonfirmasi permohonan penerjemahan dokumen melalui email atau melalui telepon selular, pastikan data yang anda input BENAR. Kemudian kami akan menerbitkan invoice tagihan jumlah biaya yang harus dibayarkan melalui email.  <br>
 Pembayaran tagihan dengan nominal yang tertera di dalam invoice tersebut, dapat dilakukan melalui rekening atas nama CV. BEST PARTNER dengan informasi lengkap rekening tujuan transfer sebagai berikut:  <br> <br>

 <table>
 	<tr>
 		<td>Nama Bank</td> <td>: BCA</td>
 	</tr>
 	<tr>
 		<td>Nama Account</td> <td>: Best Partner CV</td>
 	</tr>
 	<tr>
 		<td>No. Rekening</td> <td>: 029 900 8144</td>
 	</tr>

 </table>

 <p>Pembayaran juga dapat dilakukan melalui aplikasi pembayaran online ke rekening tujuan transfer. Berikut ini kami berikan informasi tutorial cara pembayaran melalui aplikasi pembayaran online.</p>

 <table>
 	<tr>
 		<td>Dana </td> <td>: <a href="https://www.youtube.com/watch?v=arFtFK6rQkw\" target="_BLANK">https://www.youtube.com/watch?v=arFtFK6rQkw\</a></td>
 	</tr>
 	<tr>
 		<td>OVO </td> <td>: <a href="https://www.youtube.com/watch?v=w2QLh-dUUAI" target="_BLANK">https://www.youtube.com/watch?v=w2QLh-dUUAI</a></td>
 	</tr>
 	<tr>
 		<td>Link Aja</td> <td>: <a href="https://www.youtube.com/watch?v=hC6QXxpCo-g" target="_BLANK">https://www.youtube.com/watch?v=hC6QXxpCo-g</a></td>
 	</tr>
 	<tr>
 		<td>Gopay  </td> <td>: <a href="https://www.youtube.com/watch?v=ZxzNCkhNmoA" target="_BLANK">https://www.youtube.com/watch?v=ZxzNCkhNmoA</a></td>
 	</tr>
 	<tr>
 		<td>Jenius  </td> <td>: <a href="https://www.youtube.com/watch?v=wyFcwGBlVwM" target="_BLANK">https://www.youtube.com/watch?v=wyFcwGBlVwM</a></td>
 	</tr>
 	<tr>
 		<td>Flip </td> <td>: <a href="https://www.youtube.com/watch?v=I5I1lESU7H4" target="_BLANK">https://www.youtube.com/watch?v=I5I1lESU7H4</a></td>
 	</tr>
 	<tr>
 		<td>OY </td> <td>: <a href="https://www.youtube.com/watch?v=tGvuJAQADj4" target="_BLANK">https://www.youtube.com/watch?v=tGvuJAQADj4</a></td>
 	</tr>
 </table>

 Setelah melakukan pembayaran, harap mengkonfirmasi kepada pihak Best Partner Education dengan cara mengirimkan bukti pembayaran ke alamat email finance@bestpartnereducation.com<!--  atau mengunggah foto bukti pembayaran ke https://xxxxx--> <br> <br>

 Untuk syarat dan ketentuan penerjemahan dokumen, silahkan mengakses https://bestpartnereducation.com/document-translation/term-and-condition <br>

 <p>Jika anda mempunyai pertanyaan seputar produk atau informasi lanjutan lainnya, silahkan hubungi marketing kami - counselor2@bestpartnereducation.com</p>

 *Note: <br>
 Pembayaran atas produk apapun yang berkaitan dengan BEST PARTNER EDUCATION hanya akan diterima melalui rekening atas nama BEST PARTNER CV. <br>
 BEST PARTNER EDUCATION tidak bertanggung jawab atas tindak penipuan yang mengatas namakan BEST PARTNER EDUCATION yang meminta anda melakukan pembayaran/ transfer ke rekening dengan menggunakan nama pribadi atau selain BEST PARTNER CV <br>
 Kind Regards <br>
 Best Partner Education <br>
 Untuk informasi lebih lanjut silahkan hubungi kami melalui <br>
 Phone		: (0561) 8172583 <br>
 Email		: info@bestpartnereducation.com <br>
 Website		: www.bestpartnereducation.com <br>
 Instagram	: bestpartnereducation <br>
 Line ID		: bestpartnereducation <br>
 Facebook		: bestpartner <br>
 Twitter 		: bestpartneredu1 <br>
 Youtube		: best partner education <br>
