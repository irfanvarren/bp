<h3>Data Pendaftaran Info Session</h3>
<p>Nama : {{$email->nama}}</p>
<p>No HP : {{$email->no_telepon}}</p>
<p>Email : {{$email->email}}</p>
<p>Tanggal Lahir : {{$email->tanggal_lahir.'/'.$email->bulan_lahir.'/'.$email->tahun_lahir}}</p>
<p>Nama Orang Tua : {{$email->nama_ortu}}</p>
<p>No HP Orang Tua : {{$email->no_telepon_ortu}}</p>
<p>No Telepon Rumah : {{$email->no_telepon_rumah}}</p>
<p>Pendidikan Saat Ini : {{$email->pendidikan_saat_ini}}</p>
<p>Nama Sekolah / Universitas Terakhir : {{$email->nama_sekolah_terakhir}}</p>
<p>Bidang Studi / Jurusan Yang Diminati : {{$email->minat_jurusan}}</p>
<p>Negara Tujuan : {{$email->negara_tujuan}}</p>
<p>Tingkat Studi Tujuan : {{$email->tingkat_studi_tujuan}}</p>
<p>Tahun Masuk : {{$email->tahun_masuk}}</p>
<p>Tahu Event Dari : {{$email->tahu_event_dari}}</p>
