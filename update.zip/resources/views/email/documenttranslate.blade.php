<h3>Data Translate Dokumen</h3>
<p>Nama Lengkap : {{$email->nama}}</p>
<p>Alamat Lengkap : {{$email->alamat}}</p>
<p>Kode Pos : {{$email->kode_pos}}</p>
<p>Email : {{$email->email}}</p>
<p>No Telepon / WA : {{$email->no_telepon}}</p>
<p>Permintaan : {{$email->permintaan}}</p>
