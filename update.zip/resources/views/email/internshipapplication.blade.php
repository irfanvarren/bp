<table style="width:100%;border-collapse:collapse;">
	
	<tr>
		<td style="border:1px solid black;"> Nama </td><td style="border:1px solid black;">{{$email->nama}}</td>
	</tr>	
	<tr>
		<td style="border:1px solid black;"> Tanggal Lahir </td><td style="border:1px solid black;">{{$email->tgl}}</td>
	</tr>	
	<tr>
		<td style="border:1px solid black;"> Nomor HP/WA </td><td style="border:1px solid black;">{{$email->hp}}</td>
	</tr>	
	<tr>
		<td style="border:1px solid black;"> Email </td><td style="border:1px solid black;">{{$email->email}}</td>
	</tr>	
	<tr>
		<td style="border:1px solid black;"> Sekolah </td><td style="border:1px solid black;">{{$email->sekolah}}</td>
	</tr>	
	<tr>
		<td style="border:1px solid black;"> Alamat Sekolah </td><td style="border:1px solid black;">{{$email->alamat}}</td>
	</tr>
	<tr>
		<td style="border:1px solid black;"> Jurusan </td><td style="border:1px solid black;">{{$email->jurusan}}</td>
	</tr>
	<tr>
		<td style="border:1px solid black;"> Keahlian </td><td style="border:1px solid black;">{{$email->keahlian}}</td>
	</tr>
	<tr>
		<td style="border:1px solid black;"> Cabang </td><td style="border:1px solid black;">{{$email->REF_PERUSAHAAN}}</td>
	</tr>
	<tr>
		<td style="border:1px solid black;"> Divisi </td><td style="border:1px solid black;">{{$email->divisi}}</td>
	</tr>
	<tr>
		<td style="border:1px solid black;"> Tanggal Mulai </td><td style="border:1px solid black;">{{$email->mulai}}</td>
	</tr>
	<tr>
		<td style="border:1px solid black;"> Tanggal Selesai </td><td style="border:1px solid black;">{{$email->selesai}}</td>
	</tr>
	<tr>
		<td style="border:1px solid black;"> Mengetahui Best Partner dari </td><td style="border:1px solid black;">{{$email->tahu}}</td>
	</tr>
</table>