<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
  <img src="{{asset('img/logo_berdayakan.png?v=2')}}" style="width:120px;display: block;margin:0 auto;">
  <h1 style="text-align:center"><strong>Terima Kasih</strong></h1>
  <div style="text-align:center">
    <h3>
      Telah berkunjung dan memberikan masukan. <br>
      Tanggapan Anda telah dikirim untuk segera kami proses.
    </h3>
  </div>
</body>
</html>