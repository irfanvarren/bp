
<p>Hi {{$email->nama}},</p>

<p>Terima kasih sudah mendaftar untuk magang di Best Partner Education. Kami akan segera menghubungi untuk interview.
Magang di Best Partner Education, tidak hanya mendapatkan ilmu dan pengalaman namun BP sudah menyiapkan uang saku untuk jerih payah kalian.</p>

<p>
Terima kasih
</p>

<p>Sincerely,</p>
<img src="{{asset('img/email-info.jpg')}}" style="max-width: 100%">