<h2>Data Pendaftaran Simulasi IELTS di {{$email->nama_sekolah}}</h2>
<p>Tanggal Simulasi : {{$email->tgl_simulasi}}</p>
<p>
Nama : {{$email->nama}}
</p>

<p>
  No HP : {{$email->no_hp}}
</p>
<p>
Email : {{$email->email}}
</p>
<p>Alamat : {{$email->alamat}}</p>
<p>
Tempat Kelahiran : {{$email->tempat_kelahiran}}
</p>
<p>
Tanggal Lahir : {{$email->tgl_lahir.'/'.$email->bulan_lahir.'/'.$email->tahun_lahir}}
</p>
<p>Kelas : {{$email->kelas}}</p>
