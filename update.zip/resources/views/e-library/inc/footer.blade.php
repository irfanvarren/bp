<footer id="footer" class="text-center">
   <p>Copyright 2019 &copy; Best Partner</p>
</footer>