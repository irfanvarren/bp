@extends('layouts.bp_wo_sidenav')
<style media="screen">
  p{
    text-align:justify;
  }
</style>
@section('content')
<div class="col-md-12 content-wrapper">
  <div class="col-md-12">
    <h2 style="text-align:center;">Disclaimer</h2>
    <div style="text-align:center;border:1px solid black;margin:20px auto;width:80%;">
        <p><h4>Hati - Hati Terhadap Penipuan</h4> </p>
        <p style="text-align:center;">Kami tidak pernah meminta klien untuk mentransfer uang selain ke rekening resmi perusahaan atas nama  <br>
BEST PARTNER CV <br>
Untuk info lebih lanjut silakan menghubungi kami di: +62 895-1513-9224 atau email ke: info@bestpartnereducation.com
</p>
    </div>
    <p>Semua konten yang tertera dalam situs ini adalah asli dari pihak Best Partner Education, yang berarti bahwa tidak didasarkan pada postingan, sumber materi, penyalinan dari situs maupun artikel manapun tanpa pencantuman sumber konten. Atas hal yang telah disebutkan di atas maka dengan ini ingin meyakinkan bahwa jika terjadi kemiripan dalam hal dan isi tidaklah disengaja. Harap pengguna mengerti bahwa Best Partner Education tidak menjamin keakuratan, relevansi, ketepatan waktu, atau kelengkapan informasi maupun tautan yang terdapat dalam situs ini.  </p>
    <p>Best Partner Education sebagai pemilik dari situs ini, maka dengan ini berhak untuk menghentikan, mematikan atau meniadakan konten apapun maupun situs ini secara sebagian maupun sepenuhnya. Best Partner Education membebaskan penyampaian kritik, saran, maupun komentar di dalam situs ini secara terbuka untuk diakses oleh pihak Best Partner Education, dan Best Partner Education tidak bertanggung jawab atas konten maupun tulisan yang telah disampaikan oleh pengguna. Pihak Best Partner Education dengan ini menegaskan bahwa tidak bertanggungjawab atas kelalaian yang merugikan pihak lain yang ditimbulkan oleh pihak pengguna.</p>
    <p>Konten yang ditampilkan dalam Situs ini berisi tentang penawaran layanan pendidikan, baik secara local maupun internasional dengan program / jurusan yang ditawarkan oleh mitra pendidikan Best Partner Education, informasi umum tentang negara yang memiliki jalur pendidikan, biaya yang akan ditimbulkan dari gaya hidup belajar, informasi mengenai lowongan pekerjaan di Best Partner Education.
</p>
  </div>
</div>
@stop
