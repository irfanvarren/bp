    
    {!! $options->toJson() !!}

    ##
    {!!$answers->toJson()!!}