@extends('layouts.app-auth', ['activePage' => 'student', 'titlePage' => __('Student'),'activeMenu' => 'home-management'])
<link rel="stylesheet" href="{{asset('css/selectize.bootstrap3.css')}}">
@section('content')
<div class="modal fade" id="mymodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered mymodal" style="max-width:1200px !important" role="document">

    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Students Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form class="" action="" id="form-input">

          <div class="row">
            <div class="card">
              <div class="card-header card-header-tabs card-header-rose">
                Calon Siswa
              </div>
              <div class="card-body" >
                <div class="d-flex mb-3">
                  <span class="pt-2">Cari</span><div style="flex-grow: 1;" class="mx-2"><input type="text" class="form-control" name="filter_keyword" id="filter_keyword" value=""></div><button class="btn btn-primary" type="button" id="filter-btn">search</button>
                </div>
                <div id="student-list-output"></div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <form method="post" action="{{route('admin-student.update',$student)}}" enctype="multipart/form-data" autocomplete="off" class="form-horizontal">
          @csrf
          @method('put')
          <div class="card ">
            <div class="card-header card-header-primary">
              <h4 class="card-title">{{ __('Edit Student') }}</h4>
              <p class="card-category"></p>
            </div>
            <div class="card-body ">
              <div class="row">
                <div class="col-md-12 text-right">
                  <a href="{{route('admin-student.index') }}" class="btn btn-sm btn-primary">{{ __('Back to list') }}</a>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-6">
                 <div class="row">
                  <div class="col-lg-12">
                    <button class="w-100 btn-primary btn" type="button" onclick="open_student_list()">Ambil dari calon siswa</button>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-3 col-form-label">{{ __('Kode') }}</label>
                  <div class="col-sm-9">
                    <div class="form-group{{ $errors->has('KD') ? ' has-danger' : '' }}">
                      <input type="text" class="form-control" name="KD" id="KD" value="{{$student->KD}}">
                      @if ($errors->has('KD'))
                      <span id="harga-error" class="error KD-danger" for="input-KD" >{{ $errors->first('KD') }}</span>
                      @endif
                    </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-3 col-form-label">{{ __('Nama') }}</label>
                  <div class="col-sm-9">
                    <div class="form-group{{ $errors->has('NAMA') ? ' has-danger' : '' }}">
                      <input type="text" class="form-control" name="NAMA" id="NAMA" value="{{$student->NAMA}}">
                      @if ($errors->has('NAMA'))
                      <span id="harga-error" class="error NAMA-danger" for="input-NAMA">{{ $errors->first('NAMA') }}</span>
                      @endif
                    </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-3 col-form-label">{{ __('Alamat') }}</label>
                  <div class="col-sm-9">
                    <div class="form-group{{ $errors->has('ALAMAT') ? ' has-danger' : '' }}">
                      <input type="text" class="form-control" name="ALAMAT" id="ALAMAT" value="{{$student->ALAMAT}}">
                      @if ($errors->has('ALAMAT'))
                      <span id="harga-error" class="error ALAMAT-danger" for="input-ALAMAT">{{ $errors->first('ALAMAT') }}</span>
                      @endif
                    </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-3 col-form-label">{{ __('Tanggal Lahir') }}</label>
                  <div class="col-sm-9">
                    <div class="form-group{{ $errors->has('TGL_LAHIR') ? ' has-danger' : '' }}" >
                      <input type="date" class="form-control" name="TGL_LAHIR" id="TGL_LAHIR" value="{{$student->TGL_LAHIR}}">
                      @if ($errors->has('TGL_LAHIR'))
                      <span id="harga-error" class="error TGL_LAHIR-danger" for="input-TGL_LAHIR">{{ $errors->first('TGL_LAHIR') }}</span>
                      @endif
                    </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-3 col-form-label">{{ __('Agama') }}</label>
                  <div class="col-sm-9">
                    <div class="form-group{{ $errors->has('AGAMA') ? ' has-danger' : '' }}" >
                      <input type="text" class="form-control" name="AGAMA" id="AGAMA" value="{{$student->AGAMA}}">
                      @if ($errors->has('AGAMA'))
                      <span id="harga-error" class="error AGAMA-danger" for="input-AGAMA">{{ $errors->first('AGAMA') }}</span>
                      @endif
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-3 col-form-label">{{ __('JK') }}</label>
                  <div class="col-sm-9">
                    <div class="form-group{{ $errors->has('JK') ? ' has-danger' : '' }}">
                      <input type="text" class="form-control" name="JK" id="JK"  value="{{$student->JK}}">
                      @if ($errors->has('JK'))
                      <span id="harga-error" class="error JK-danger" for="input-JK">{{ $errors->first('JK') }}</span>
                      @endif
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-3 col-form-label">{{ __('Email') }}</label>
                  <div class="col-sm-9">
                    <div class="form-group{{ $errors->has('EMAIL') ? ' has-danger' : '' }}">
                      <input type="text" class="form-control" name="EMAIL" id="EMAIL" value="{{$student->EMAIL}}">
                      @if ($errors->has('EMAIL'))
                      <span id="harga-error" class="error EMAIL-danger" for="input-EMAIL">{{ $errors->first('EMAIL') }}</span>
                      @endif
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-3 col-form-label">{{ __('NIK') }}</label>
                  <div class="col-sm-9">
                    <div class="form-group{{ $errors->has('REF_NIK') ? ' has-danger' : '' }}">
                      <input type="text" class="form-control" name="REF_NIK" id="REF_NIK" value="{{$student->REF_NIK}}">
                      @if ($errors->has('REF_NIK'))
                      <span id="harga-error" class="error REF_NIK-danger" for="input-REF_NIK">{{ $errors->first('REF_NIK') }}</span>
                      @endif
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-3 col-form-label">{{ __('NPWP') }}</label>
                  <div class="col-sm-9">
                    <div class="form-group{{ $errors->has('REF_NPWP') ? ' has-danger' : '' }}">
                      <input type="text" class="form-control" name="REF_NPWP" id="REF_NPWP" value="{{$student->REF_NPWP}}">
                      @if ($errors->has('REF_NPWP'))
                      <span id="harga-error" class="error REF_NPWP-danger" for="input-REF_NPWP">{{ $errors->first('REF_NPWP') }}</span>
                      @endif
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-3 col-form-label">{{ __('Akta') }}</label>
                  <div class="col-sm-9">
                    <div class="form-group{{ $errors->has('REF_AKTA') ? ' has-danger' : '' }}">
                      <input type="text" class="form-control" name="REF_AKTA" id="REF_AKTA" value="{{$student->REF_AKTA}}">
                      @if ($errors->has('REF_AKTA'))
                      <span id="harga-error" class="error REF_AKTA-danger" for="input-REF_AKTA">{{ $errors->first('REF_AKTA') }}</span>
                      @endif
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="row">
                  <div class="col-lg-12 p-3 mb-3" style="border:1px solid black">
                    <div>Gambar</div>
                    <img src="">
                    <input type="file" name="FILE_PIC" id="FILE_PIC">
                  </div>
                  <div class="col-lg-12 p-3" style="border:1px solid black">
                    <div class="row mb-3">
                      <div class="col-lg-3">
                        Negara
                      </div>
                      <div class="col-lg-9">
                        <select class="selectize form-control" id="REF_NEGARA" name="REF_NEGARA">
                          <option value=""> - Pilih Negara -</option>
                          @foreach($countries as $country)
                          <option value="{{strtoupper($country->name)}}" {{strtoupper($country->name) == $student->REF_NEGARA ? 'selected' : ''}}>{{$country->name}}</option>
                          @endforeach
                        </select>
                      </div>
                    </div>
                    <div class="row mb-3">
                      <div class="col-lg-3">
                        Pulau
                      </div>
                      <div class="col-lg-9">
                       <select class="selectize form-control" id="REF_PULAU" name="REF_PULAU">
                        <option value=""> - Pilih Pulau -</option>

                      </select>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-lg-3">
                      Provinsi
                    </div>
                    <div class="col-lg-9">
                     <select class="selectize form-control" id="REF_PROVINSI" name="REF_PROVINSI">
                      <option value=""> - Pilih Provinsi -</option>
                    </select>
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-lg-3">
                    Kota
                  </div>
                  <div class="col-lg-9">
                   <select class="selectize form-control" id="REF_KOTA" name="REF_KOTA">
                    <option value=""> - Pilih Kota -</option>
                  </select>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-lg-3">
                  Kecamatan
                </div>
                <div class="col-lg-9">
                 <select class="selectize form-control" id="REF_KEC" name="REF_KEC">
                  <option value=""> - Pilih Kecamatan -</option>
                </select>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-3">
                Kelurahan
              </div>
              <div class="col-lg-9">
               <select class="selectize form-control" id="REF_KEL" name="REF_KEL">
                <option value=""> - Pilih Kelurahan -</option>
              </select>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>
<div class="card-footer ml-auto mr-auto">
  <button type="submit" class="btn btn-primary">{{ __('Edit Student') }}</button>
</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>

@endsection
@push('js')
<script type="text/javascript" src="{{asset('js/selectize.js')}}"></script>
<script type="text/javascript">
 var token = $("input[name='_token']").val();
 var type = "student-candidate";
 var page = null;
 var REF_NEGARA = "{{$student->REF_NEGARA}}";
 var REF_PULAU = "{{$student->REF_PULAU}}";
 var REF_PROVINSI = "{{$student->REF_PROVINSI}}";
 var REF_KOTA = "{{$student->REF_KOTA}}";
 var REF_KEC = "{{$student->REF_KEC}}";
 var REF_KEL = "{{$student->REF_KEL}}";


 $(document).ready(function(){
  if(REF_NEGARA != ""){
    island_ajax(REF_NEGARA,REF_PULAU);
  }

});
 $('.selectize').selectize();
 $("#Student_type").on('change',function(){
  $('#hide-content').show();
  if($(this).val() == "image") {
    $('#hide-text').hide();
    $('#hide-image').show();
  }else{
    $('#hide-image').hide();
    $('#hide-text').show();
  }
});



 function open_student_list(){
  $('#mymodal').modal('toggle');
  var keyword = $('#filter_keyword').val();
  $.ajax({
    url:"{{route('admin-student.lists')}}",
    method:"GET",
    data: {
      _token: token,
      type:type,
      keyword:keyword
    },
    success: function(data) {
      $('#student-list-output').html(data);
    },
    error:function(){

    }
  });
}

var filter_func = function(){
  var keyword = $('#filter_keyword').val();
  $.ajax({
    url : "{{route('admin-student.lists')}}",
    method: "GET",
    data : {
      _token : token,
      keyword : keyword,
      page:page,
      type: type
    },
    success: function(data){
      $('#student-list-output').html(data);
    },
    error: function(){

    },complete: function(){

    }
  });

};
var keyword_keyup = debounce(filter_func, 350);

document.getElementById('filter_keyword').addEventListener('keyup', keyword_keyup);
document.getElementById('filter-btn').addEventListener('click', filter_func);

function filter_func_pagination(no){
  page = no;
  filter_func();
}

function select_student(e){
  var data_student = JSON.parse(e.getAttribute("data-student"));
  console.log(data_student);
  $.ajax({
    url : "{{route('admin-student.check-student-exist')}}",
    method : "GET",
    data:{
      _token:token,
      NAMA : data_student.NAMA,
      REF_NIK : data_student.REF_NIK,
      EMAIL : data_student.EMAIl
    },success:function(data){
      $('#mymodal').modal('toggle');
      $('#REF_SISWA').val(data_student.KD);
      $('#NAMA').val(data_student.NAMA);
      $('#JK').val(data_student.JK);
      $('#EMAIL').val(data_student.EMAIL);
      $('#KONTAK_1').val(data_student.KONTAK_1);
      $('#KONTAK_2').val(data_student.KONTAK_2);
      $('#KONTAK_3').val(data_student.KONTAK_3);
      $('#REF_NIK').val(data_student.REF_KTP);
      $('#TGL_LAHIR').val(data_student.TGL_LAHIR);
      $('#ALAMAT').val(data_student.ALAMAT);
      $('#REF_NPWP').val(data_student.REF_NPWP);
      $('#AGAMA').val(data_student.AGAMA);
      if(data_student.REF_NEGARA != null){
       island_ajax(data_student.REF_NEGARA);
     }else{
      island_ajax("INDONESIA");
    }
    $('#OCCLVL').val(data_student.TINGKAT_PEKERJAAN);
    $('#OCCSEC').val(data_student.SEKTOR_PEKERJAAN);
    $('#OCCSEC').val(data_student.SEKTOR_PEKERJAAN);
    $('#EDUC').val(data_student.TINGKAT_PENDIDIKAN);
    $('#COUNTRY').val(data_student.NEGARA_TUJUAN);
    $('#PURPOSE').val(data_student.ALASAN);
    if(data_student.KONTAK != ""){
      $('#KONTAK_1').val(data_student.KONTAK);
    }
  },error:function(){

  }
});

}

$('#REF_NEGARA').on('change',function(){
  island_ajax($(this).val());
});

function island_ajax(REF_NEGARA,REF_PULAU = null){

  $.ajax({
    url: "{{route('island-ajax')}}",
    method: "POST",
    data: {
      _token: token,
      REF_NEGARA : REF_NEGARA
    },
    success: function(data) {
      $('#REF_PULAU').selectize()[0].selectize.destroy();
    
      var $select = $('#REF_PULAU').selectize({
        options : data,
        valueField: 'NAMA',
        labelField: 'NAMA',
        searchField: 'NAMA',
      });
      var selectize = $select[0].selectize;
        if(REF_PULAU != null){
          selectize.setValue(REF_PULAU);
        }
        return true;
      },
      error: function(request, status, error) {
        alert(request.responseText);
        return false;
      }
    });

}

$('#REF_PULAU').on('change',function(){
    if(REF_PROVINSI != ""){     
      province_ajax($(this).val(),REF_PROVINSI);
    }else{   
  province_ajax($(this).val());
  }
});

function province_ajax(REF_PULAU,REF_PROVINSI = null){

  $.ajax({
    url: "{{route('province-ajax')}}",
    method: "POST",
    data: {
      _token: token,
      REF_NEGARA : $('#REF_NEGARA').val(),
      REF_PULAU : REF_PULAU
    },
    success: function(data) {
     $('#REF_PROVINSI').selectize()[0].selectize.destroy();
    
      var $select = $('#REF_PROVINSI').selectize({
        options : data,
        valueField: 'NAMA',
        labelField: 'NAMA',
        searchField: 'NAMA',
      });
      var selectize = $select[0].selectize;
        if(REF_PROVINSI != null){

          selectize.setValue(REF_PROVINSI);
        }
        return true;
      },
      error: function(request, status, error) {
        alert(request.responseText);
        return false;
      }
    });

}

$('#REF_PROVINSI').on('change',function(){
     if(REF_KOTA != ""){     
    city_ajax($(this).val(),REF_KOTA);
     }else{
  city_ajax($(this).val());
  }
});

function city_ajax(REF_PROVINSI,REF_KOTA = null){

  $.ajax({
    url: "{{route('city-ajax')}}",
    method: "POST",
    data: {
      _token: token,
      REF_PROVINSI : REF_PROVINSI
    },
    success: function(data) {
      $('#REF_KOTA').selectize()[0].selectize.destroy();
    
      var $select = $('#REF_KOTA').selectize({
        options : data,
        valueField: 'NAMA',
        labelField: 'NAMA',
        searchField: 'NAMA',
      });
      var selectize = $select[0].selectize;
        if(REF_KOTA != null){
          selectize.setValue(REF_KOTA);
        }
        return true;
      },
      error: function(request, status, error) {
        alert(request.responseText);
        return false;
      }
    });

}

$('#REF_KOTA').on('change',function(){
   if(REF_KEC != ""){     
  district_ajax($(this).val(),REF_KEC);
}else{
   district_ajax($(this).val());
}
});

function district_ajax(REF_KOTA,REF_KEC = null){

  $.ajax({
    url: "{{route('district-ajax')}}",
    method: "POST",
    data: {
      _token: token,
      REF_KOTA : REF_KOTA
    },
    success: function(data) {
      $('#REF_KEC').selectize()[0].selectize.destroy();
    
      var $select = $('#REF_KEC').selectize({
        options : data,
        valueField: 'NAMA',
        labelField: 'NAMA',
        searchField: 'NAMA',
      });
      var selectize = $select[0].selectize;
        if(REF_KEC != null){
          selectize.setValue(REF_KEC);
        }
        return true;
      },
      error: function(request, status, error) {
        alert(request.responseText);
        return false;
      }
    });

}

$('#REF_KEC').on('change',function(){
   if(REF_KEL != ""){     
  sub_district_ajax($(this).val(),REF_KEL);
}else{
  sub_district_ajax($(this).val());
}
});

function sub_district_ajax(REF_KEC,REF_KEL = null){

  $.ajax({
    url: "{{route('sub-district-ajax')}}",
    method: "POST",
    data: {
      _token: token,
      REF_KEC : REF_KEC
    },
    success: function(data) {
         $('#REF_KEL').selectize()[0].selectize.destroy();
    
      var $select = $('#REF_KEL').selectize({
        options : data,
        valueField: 'NAMA',
        labelField: 'NAMA',
        searchField: 'NAMA',
      });
      var selectize = $select[0].selectize;
        if(REF_KEL != null){
          selectize.setValue(REF_KEL);
        }
        return true;
      },
      error: function(request, status, error) {
        alert(request.responseText);
        return false;
      }
    });

}
</script>
@endpush
