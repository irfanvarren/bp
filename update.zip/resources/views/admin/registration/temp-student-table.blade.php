	<div class="table-responsive">
		<table class="table table-bordered">
			<tr>
				<th>No Siswa</th><th>Title</th><th>Nama</th><th>JK</th><th>Tgl Lahir</th><th>Agama</th><th>Alamat</th><th>Kota</th><th>Action</th>
			</tr>
			@foreach($temp_student_detail as $temp)
			<tr>
				<th>{{$temp->REF_SISWA}}</th><th>{{$temp->TITLE}}</th><th>{{$temp->NAMA}}</th><th>{{$temp->JK}}</th><th>{{$temp->TGL_LAHIR}}</th><th>{{$temp->AGAMA}}</th><th>{{$temp->ALAMAT}}</th><th>{{$temp->REF_KOTA}}</th><th><button class="btn btn-danger" type="button" onclick="delete_temp_student('{{$temp->KD_GABUNG}}','{{$temp->REF_SISWA}}')">Delete</button></th>
			</tr>
			@endforeach
		</table>
	</div>