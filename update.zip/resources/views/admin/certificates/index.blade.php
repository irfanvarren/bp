@extends('layouts.app-auth', ['activePage' => '','activeMenu' => '', 'titlePage' => __('Certificate Tracking')])

@section('content')
<div class="content">

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header card-header-primary">
						<h4 class="card-title ">{{ __('Certificates') }}</h4>
						<p class="card-category"> {{ __('Here you can manage certificates') }}</p>
					</div>
					<div class="card-body">
						

						<table class="table table-bordered">
							<tr>
								<th>Kode Sertifikat</th><th>Paket</th><th>Level</th><th>Cabang</th><th>Murid</th><th>Action</th>
							</tr>
							@foreach($certificates as $certificate)
							<tr>
								<td>{{$certificate->KD_GABUNG}}</td><td>{{$certificate->REF_PAKET}}</td><td>{{$certificate->REF_LEVEL}}</td><td>{{$certificate->REF_PERUSAHAAN}}</td><td>{{$certificate->SISWA_NAMA}}</td><td>Action</td>
							</tr>
							@endforeach
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection

