
<?php $__env->startSection('title', 'Young Learners'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12 content-header" style="/*background-image: linear-gradient(to bottom right, #244272,#99c0ff);*/background-image:url('<?php echo e(asset('/img/young learner.jpg')); ?>');">
	<div style="background-image: linear-gradient(to bottom right, #1c4e9e,#74bff2);width: 100%;height: 100%;position: absolute;top:0;left: 0;z-index: 1;opacity: 0.7;"></div>
		<div class="content-title" >
	<p><h1>Young Learners</h1></p>
	<p>Kelas anak anak (kelas: 1-6 SD)</p>
	<a href="https://wa.me/6283151281946" target="_blank" class="content-btn"> Daftarkan Sekarang</a>
	</div>
</div>
<div class="col-md-12 content-wrapper class-content-wrapper">
	<div class="col-md-12 content-nav">
		<nav>
			<a onclick="scroll_to('deskripsi')">
				Deskripsi
			</a>
			<a onclick="scroll_to('learn-exp')">
				Pengalaman Belajar
			</a>
			<a onclick="scroll_to('target')">
				Target Belajar
			</a>
		</nav>
	</div>
	<div class="col-md-12 class-content" id="deskripsi">
		<div class="col-md-8" style="padding:0;">
		<h2>About This Program</h2>
		<p>Young Learner Class adalah program untuk anak-anak dari kelas 1-6 SD. Sebagai siswa BP, anak anda akan mendapatkan 3 level kursus dengan kelas yang aktif dan interaktif dengan mengutamakan English Communicative Learning. Anak-anak akan belajar kemampuan bahasa Inggris secara mendasar untuk mengembangkan keterampilan sosial dan kognitif mereka.</p>
		<h2>Mengembangkan kecintaan berbahasa Inggris</h2>
		<p>
			<ol class="col-md-12">
				<li>Setiap kelas menggunakan bahasa Inggris sebagai bahasa pengantar guna membantu anak terbiasa dengan bahasa Inggris sebagai bahasa sehari-hari. </li>
				<li>Lagu, video, cerita pendek, kartu flash, craft, dan majalah dinding interaktif digunakan sebagai alat bantu yang menambah variasi belajar di kelas. </li>
				<li>
					Pengajar profesional kami menciptakan suasana belajar bahasa Inggris yang menyenangkan dan mendalam sehingga anak-anak akan belajar menggunakan kemampuan dalam suasana yang nyata.
				</li>
			</ol>
		</p>
		<H2>Kelas & Jadwal Belajar</H2>
		<p>
			Setiap anak akan belajar 2 kali dalam semingggu dengan jam pelajaran yang tidak mengganggu jam belajar sekolah anak. Setiap siswa, akan melewati jenjang level belajar yang dimulai dengan kelas “Starters”, “Movers” dan “Flyers”.
		</p>
		</div>
		<div class="col-md-4 class-sidebar">
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/young learners/Mengembangkan Kemampuan sejak dini.png')); ?>">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>Mengembangkan Kemampuan sejak dini</h3>
					<p>Materi khusus didesain melalui riset dan pengembangan tentang bagaimana anak mengembangkan kemampuan sejak usia dini. </p>
				</div>
			</div>
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/Young learners/Teaching.png')); ?>">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>Metode Pengajaran Yang Efektif</h3>
					<p>Materi dibentuk secara inovatif dengan mencakup kemampuan berbicara, mendengar, membaca dan menulis dengan menerapkan English Communicative Learning yang menyenangkan. </p>
				</div>
			</div>
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/young learners/500 Vocabular.png')); ?>">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>500 Vocabulary</h3>
					<p>Setiap anak akan dibekali 500 kosa kata baru yang akan berguna selama memasuki jenjang sekolah dasar. </p>
				</div>
			</div>
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/young learners/Max 6 Siswa.png')); ?>">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>Max 6 Siswa</h3>
					<p>Kelas kecil intensif (max 6 siswa di setiap kelasnya) membantu anak anda untuk lebih fokus belajar.  </p>
				</div>
			</div>

		</div>
	</div>

	<div class="col-md-12 target-wrapper" id="target" style="border-top:1px solid #ccc">
		<h1> Target Pembelajaran</h1>
		<div class="col-md-4 target tablink" onclick="openTabs(event,'listening')">
			<div class="target-header"><img src="<?php echo e(asset('/img/listening2.png')); ?>">
			<p>Mendengar</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12"><b>Phonics dan bunyi suku kata</b> <br> Siswa belajar untuk membuat dan mengenal bunyi kata dalam bahasa Inggris. Siswa belajar melafalkan bunyi dan dibantu untuk mengucapkan kata dengan benar.</div>
				<div class="col-md-12"> <b>Kata dan frase singkat</b> <br>Siswa belajar mendengarkan kata dan frase singkat dengan media gambar, dialog, dan informasi singkat. </div>
			</div>
		</div>
		<div class="col-md-4 target tablink" onclick="openTabs(event,'reading')">
			<div class="target-header">
			<img src="<?php echo e(asset('/img/speaking2.png')); ?>">
			<p>Berbicara</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12"><b>Percakapan singkat</b><br>Siswa mengasah kepercayaan diri untuk berdialog singkat mengenai informasi pribadi. </div>
				<div class="col-md-12"><b>Merespons pertanyaan singkat</b><br>Siswa mempelajari bagaimana mendeskripsikan suatu objek, memahami instruksi singkat, dan menjawab pertanyaan. </div>
			</div>
		</div>
		<div class="col-md-4 target tablink" onclick="openTabs(event,'writing')">
			<div class="target-header">
			<img src="<?php echo e(asset('/img/writing2.png')); ?>">
			<p>Membaca dan menulis</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12"><b>Kata dan kalimat pendek</b><br>Siswa dapat membaca deksripsi singkat dan sederhana mengenai beberapa objek. Siswa juga dapat mengerti pernyataan singkat dan dapat menulis kata dan frase pendek. </div>
				<div class="col-md-12"><b>Kata dan ejaan dalam bahasa Inggris</b><br>Mengetahui strategi pengerjaan dan standar penilaian writing test pada IELTS Official Test.</div>

			</div>
		</div>
	</div>
		<div class="col-md-12 learn-exp" id="learn-exp">
		<h1>Pengalaman Belajar</h1>
		<div class="learn-vid-wrapper col-md-12">
			<div class="col-md-4">
				<div class="col-md-12 learn-vid">
					<video width="100%" height="90%" controls>
  <source src="<?php echo e(asset('/video/evolution_hospitality.mp4')); ?>" type="video/mp4">
Your browser does not support the video tag.
</video>
					<div class="video-desc">
						Deskripsi Video
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="col-md-12 learn-vid">
					<video width="100%" height="90%" controls>
  <source src="<?php echo e(asset('/video/evolution_hospitality.mp4')); ?>" type="video/mp4">
Your browser does not support the video tag.
</video>
					<div class="video-desc">
						Deskripsi Video
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="col-md-12 learn-vid">
					<video width="100%" height="90%" controls>
  <source src="<?php echo e(asset('/video/evolution_hospitality.mp4')); ?>" type="video/mp4">
Your browser does not support the video tag.
</video>
					<div class="video-desc">
						Deskripsi Video
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
function scroll_to(div){
	 $('html, body').animate({
        scrollTop: $("#"+div).offset().top - 230
    }, 1000);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_wo_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views//language/english/young-learners.blade.php ENDPATH**/ ?>