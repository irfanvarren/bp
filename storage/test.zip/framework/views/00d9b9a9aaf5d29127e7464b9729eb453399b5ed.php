<div class="wrapper ">
<?php if(auth()->user()->hasRole('Admin') && Auth::guard('web')): ?>
  <?php echo $__env->make('layouts.navbars.sidebar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
  <?php echo $__env->make('layouts.navbars.sidebar-member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

  <div class="main-panel">
<?php if(auth()->user()->hasRole('Admin') && Auth::guard('web')): ?>
    <?php echo $__env->make('layouts.navbars.navs.admin-auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('layouts.navbars.navs.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('content'); ?>
  <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
  </div>
</div>
<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/layouts/page_templates/auth.blade.php ENDPATH**/ ?>