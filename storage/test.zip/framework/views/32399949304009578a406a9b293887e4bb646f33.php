
<?php $__env->startSection('title', 'About Us'); ?>
<?php $__env->startSection('content'); ?>
<!--
<div class="content-header col-md-12" style="background-image:url('/img/bp_services.jpg');">
	<h1>Our Services</h1>
</div>
-->
<div class="content-wrapper language-list-content col-md-12" >

	<div class="col-md-12 products-wrapper">
		<a href="/products/language/english">
		<div class="col-md-4">
			<div class="col-md-12 product">
				<div class="col-md-12 product-top" style="background-image: url('<?php echo e(asset('/img/english.png')); ?>')">

				</div>
				<div class="col-md-12 product-bottom">
					<h1>English</h1>
				</div>

			</div>
		</div>
		</a>
		<a href="/products/language">
		<div class="col-md-4">
			<div class="col-md-12 product">
				<div class="col-md-12 product-top" style="background-image: url('<?php echo e(asset('/img/cineeeee.png')); ?>')">

				</div>
				<div class="col-md-12 product-bottom">
					<h1>Mandarin</h1>
				</div>

			</div>
		</div>
		</a>
		<a href="/products/language">
		<div class="col-md-4">
			<div class="col-md-12 product">
				<div class="col-md-12 product-top" style="background-image: url('<?php echo e(asset('/img/prancis.png')); ?>')">

				</div>
				<div class="col-md-12 product-bottom">
					<h1>French</h1>
				</div>

			</div>
		</div>
		</a>
		<a href="/products/language">
		<div class="col-md-4">
			<div class="col-md-12 product">
				<div class="col-md-12 product-top" style="background-image: url('<?php echo e(asset('/img/german.png')); ?>')">

				</div>
				<div class="col-md-12 product-bottom">
					<h1>German</h1>
				</div>

			</div>
		</div>
		</a>
		<a href="/products/language">
		<div class="col-md-4">
			<div class="col-md-12 product">
				<div class="col-md-12 product-top" style="background-image: url('<?php echo e(asset('/img/korean.png')); ?>')">

				</div>
				<div class="col-md-12 product-bottom">
					<h1>Korean</h1>
				</div>

			</div>
		</div>
		</a>
		<a href="/products/language">
		<div class="col-md-4">
			<div class="col-md-12 product">
				<div class="col-md-12 product-top" style="background-image: url('<?php echo e(asset('/img/japan.png')); ?>')">

				</div>
				<div class="col-md-12 product-bottom">
					<h1>Japanese</h1>
				</div>

			</div>
		</div>
		</a>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_wo_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views//language/language.blade.php ENDPATH**/ ?>