<style media="screen">
	.news-article{
		box-shadow:0px 0px 3px #555;
		background:white;
		padding:30px !important;
	}
	.news-article-wrapper{
		padding:40px 15px;
		max-width:87.5%;
		flex: 0 0 87.5%;
	}
	.news-tags:before{
		content:'# ';
	}


	@media  screen and (max-width:480px){


	}
</style>
<?php $__env->startSection('news-title',implode(' ',array_map("ucfirst",explode('-',$news->slug)))); ?>
<?php $__env->startSection('news-image'); ?>
<?php echo e(Storage::disk('news')->url($news->image)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('news-desc'); ?>
<?php echo str_limit(strip_tags($news->body),100,$end = "..."); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title',implode(' ',array_map("ucfirst",explode('-',$news->slug)))); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-8 content-wrapper news-article">
	<div class="col-md-12">
<div class="row">

<div class="col-md-12">

<h1><?php echo e(ucwords($news->title)); ?></h1>
<div><?php echo e(date("l, d F Y",strtotime($news->created_at))); ?></div>
<br>
</div>
<div class="col-md-12" style="margin-bottom:1rem;">


<div class="sharethis-inline-share-buttons"></div>

</div>
<div class="col-md-12">
	<img style="width:100%;height:auto;" src="<?php echo e(Storage::disk('news')->url($news->image)); ?>" alt="">
</div>

<div class="col-md-12" style="overflow:auto">
	<br>
	<?php echo $news->body; ?>

</div>
<div class="col-md-12">
	<?php $__currentLoopData = $this_tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	 <a class="news-tags" href="<?php echo e(url('media/news/tags/'.$tag)); ?>"><?php echo e($tag); ?></a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>

</div>
</div>
<?php $__env->startSection('more-script'); ?>
	<script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=5da17dc4bfe4730012572504&product=inline-share-buttons" async="async"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/news-view.blade.php ENDPATH**/ ?>