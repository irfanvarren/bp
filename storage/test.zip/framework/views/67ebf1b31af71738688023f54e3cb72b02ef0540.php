<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Fonts -->

        <!-- Styles -->
    </head>
    <body>
        <div class="container">
            <header class="row">
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <div id="main" class="row">

            <?php echo $__env->yieldContent('content'); ?>
    </div>

    <footer class="row">
      <div class="col-md-12">

          <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </footer>
        </div>
        <?php echo $__env->yieldPushContent('more-script'); ?>
        <!-- </body></html> -->
    </body>
</html>
<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/layouts/bp_wo_sidenav.blade.php ENDPATH**/ ?>