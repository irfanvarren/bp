<?php $__env->startSection('title', __('Server Maintenance')); ?>
<?php $__env->startSection('image'); ?>
<div class="">
<img src="<?php echo e(asset('img/errors')); ?>" alt="">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/errors/503.blade.php ENDPATH**/ ?>