
<style media="screen">
  .market-wrapper {
    padding: 15 30px !important;
    min-height: 300px;
  }

  .market {
    padding: 15px;
  }

  .market-content {
    height: 350px;
    border-radius: 20px 20px 0 0;
/*    border: 1px solid #bcbcbc;*/
    box-shadow: 0 0 2px #333;
    padding: 0 !important;
  }

  .market-img {
    position: relative;
    height: 75%;
    border-radius: 20px 20px 0px 0;
    overflow: hidden;
  }

  .market-desc {
    height: 25%;
    padding: 10px 15px;
    background:white;
    text-align: left;
  }

  .market-name {
    position: absolute;
      bottom: 0;
      right: 0;
      color: white;
      z-index: 999;
      font-size: 19px;
      width: 100%;
      font-family: impact;
      text-shadow: 0px 0px 3px black;
      /* font-weight: bolder; */
      /* background: #494949; */
      background: rgba(0,0,0,0.4);
      letter-spacing: 0.5px;
      padding: 8px 12px;

  }

  .market-address {
    line-height: 1.8em;
    max-height: 3.6em;
    display: -webkit-box;
    overflow: hidden;
    text-overflow: ellipsis;
    -webkit-line-clamp: 2;
    /* number of lines to show */
    -webkit-box-orient: vertical;
  }

  .member-menu {
    text-align: center;
    padding: 10px 0 !important;
    font-size: 18px;
  }

  .member-menu:hover {
    cursor: pointer;
  }

  .member-menu-divider {
    width: 2px;
    height: 25px;
    float: right;
    background: #6e6e6e;
  }

  .merchant-content-wrapper {
    min-height: 300px;
  }

  .merchant-not-found {
    text-align: center;
    padding: 100px;
  }

  .member-dropdown-content {
    display: none;
    position: absolute;
    width: 80%;
    margin-top: 5px;
    left: 50%;
    transform: translateX(-50%);
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
    z-index: 1;
  }

  .member-dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
  }

  .member-dropdown-content a:hover {
    background-color: #f1f1f1
  }

  .dropdown:hover .member-dropdown-content {
    display: block;
  }
  .loading-wrapper{
    width:100vw;
    height:100vh;
    position:fixed;
    top:0;
    left:0;
    z-index:9999999;
    display:none;
    background:rgba(255,255,255,1);
  }
  .loading-wrapper img{
    display:block;
    margin:0 auto;
    width:500px;
    position:absolute;
    top:50%;
    left:50%;
    transform:translate(-50%,-50%);

  }
</style>
<div class="loading-wrapper">
  <img src="<?php echo e(asset('/img/loading.gif')); ?>" alt="">
</div>
<?php $__env->startSection('content'); ?>
<div class="col-md-12 content-wrapper" style="padding:0;">
  <?php echo csrf_field(); ?>
  <div class="slick-slider">
    <div class="slick-slide">


      <div class="col-md-12 home-title-wrapper">
        <div class="col-md-12 slider-img" style="background-image:url('<?php echo e(asset('/img/ielts.jpg')); ?>');height:420px;background-size:100%;">

        </div>
        <!--
       <div class="home-title">
       <h1>Education Consultant</h1>
       <p class="col-md-12">
         Kami memberikan layanan jasa konsultasi studi luar negeri dengan biaya gratis dengan konsultan professional kami, ditambah lagi dengan pelatihan interview sampai anda lancar dan bisa.
         </p>
         <a  href="https://www.youtube.com/channel/UCicDSptmlROwc3B6kYEbUjw" target="_BLANK" class="home-btn home-btn1"> <i class=" fa fa-youtube-play" style="margin-right:15px;color:white;"></i> Watch Video </a>
       </div>
<div class="col-md-6 slider-img slider-img1" style="background-image:url('<?php echo e(asset('/img/Education Consultant.png')); ?>');"> </div>
-->
      </div>
    </div>

  </div>

  <div class="col-md-12 merchant-content-wrapper">
    <div class="row">
      <div class="col-md-6 member-menu dropdown" onclick="open_service()">
        <span class="">
          Pilih Layanan
        </span> <i class="fa fa-angle-down"> </i>
        <div class="member-menu-divider"></div>

        <div class="member-dropdown-content">
          <a href="#">Link 1</a>
          <a href="#">Link 2</a>
          <a href="#">Link 3</a>
        </div>
      </div>
      <div class="col-md-6 member-menu" onclick="open_promo()">
        <span class="" style="margin-right:5px;">
          Cari Promo Disini
        </span> <i class="fa fa-search"></i>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12 market-wrapper"  id="output-merchant">

        <?php if(empty($merchant->all())): ?>

        <div class="row merchant-not-found">
          <h2 class="col-md-12">Merchant Tidak Ditemukan !</h2>
        </div>

        <?php else: ?>
          <div class="rows">
                <h2>Merchant</h2>
          </div>
        <div class="row">

          <?php $__currentLoopData = $merchant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_merchant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="col-md-4 market">
                    <a href="<?php echo e(url('member-les/merchant/'.$data_merchant->id)); ?>">
            <div class="col-md-12 market-content">
              <div class="market-img">

                <img src="<?php echo e(asset('img/ielts.jpg')); ?>" style="width:100%;" alt="">
                <div class="market-name">
<?php echo e(ucwords($data_merchant->nama_merchant)); ?>

                </div>
                          </div>
              <div class="market-desc">
                <div>
                Alamat : <?php echo e($data_merchant->alamat); ?>

                </div>
                <div>
                Email : <?php echo e($data_merchant->email); ?>

                </div>
                <div>
                No Telepon : <?php echo e($data_merchant->no_telepon); ?>

                </div>
              </div>
            </div>
                </a>
          </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <?php endif; ?>
      </div>
      <?php echo e($merchant->links()); ?>

    </div>
  </div>
</div>
<script type="text/javascript">
  function open_promo() {
    //alert('test');
    var token = $("input[name='_token']").val();
    $('.loading-wrapper').show();
    //  alert(token);
    $.ajax({
      url: "<?php echo route('member-promo-ajax') ?>",
      method: 'POST',
      data: {
        _token: token
      },
      success: function(data) {
        $('.loading-wrapper').hide();
        $('#output-merchant').html(data);
      },
      error: function() {
        //handle errors
        alert('error...');
      }
    });

  }

  function open_service() {
    var token = $("input[name='_token']").val();
    $('.loading-wrapper').show();
    //  alert(token);
    $.ajax({
      url: "<?php echo route('member-service-ajax') ?>",
      method: 'POST',
      data: {
        _token: token
      },
      success: function(data) {
        $('.loading-wrapper').hide();
        $('#output-merchant').html(data);
      },
      error: function() {
        //handle errors
        alert('error...');
      }
    });

  }
  $('#course').change(function() {

    $("#level .select-ajax").remove();


  });

  $(document).ready(function() {
    $('.slick-slider').slick({
      infinite: true,
      slidesToScroll: 1,
      slidesToShow: 1,
      lazyLoad: 'ondemand',
      rows: 1,
      prevArrow: '<a class="myslick-prev myslick-nav myslick-nav2" ><i class="fa fa-angle-left"></i></a>',
      nextArrow: '<a class="myslick-next myslick-nav myslick-nav2"> <i class="fa fa-angle-right"></i> </a>',
      autoplay: true,
      autoplaySpeed: 4500,

      responsive: [{
        breakpoint: 600,
        settings: {
          arrows: false,
          adaptiveHeight: true,
        }
      }]
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_wo_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/member-les/index.blade.php ENDPATH**/ ?>