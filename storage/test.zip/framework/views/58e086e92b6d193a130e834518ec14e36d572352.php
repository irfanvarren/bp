

<?php $__env->startSection('title', 'TOEFL Class'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12 content-header" style="/*background-image: linear-gradient(to bottom right, #244272,#99c0ff);*/background-image:url('<?php echo e(asset('/img/toefl.jpg')); ?>');">
	<div style="background-image: linear-gradient(to bottom right, #1c4e9e,#74bff2);width: 100%;height: 100%;position: absolute;top:0;left: 0;z-index: 1;opacity: 0.7;"></div>
		<div class="content-title" >
	<p><h1>TOEFL Class</h1></p>
	<p>TOEFL ITP & iBT Preparation</p>
		<a href="https://wa.me/6283151281946" target="_blank" class="content-btn"> Daftarkan Sekarang</a>
	</div>
</div>
<div class="col-md-12 content-wrapper class-content-wrapper">
	<div class="col-md-12 content-nav">
		<nav>
			<a onclick="scroll_to('deskripsi')">
				Deskripsi
			</a>
			<a onclick="scroll_to('learn-exp')">
				Pengalaman Belajar
			</a>
			<a onclick="scroll_to('target')">
				Target Belajar
			</a>
		</nav>
	</div>
	<div class="col-md-12 class-content" id="deskripsi">
		<div class="col-md-8" style="padding:0;">
		<h2>About This Program</h2>
		<p>Program ini sangat cocok untuk siswa yang tengah mempersiapkan diri untuk menghadapi Test resmi PBT (ITP-TOEFL). Siswa BP sendiri, akan mempelajari secara intensif bentuk tes dalam PBT (ITP-TOEFL)mulai dari Listening Comprehension, Structure dan written expression, Reading comprehension dan strategi untuk menjawab. Setiap siswa akan belajar menggunakan materi tes-tes TOEFL otentik yang mirip dengan tes sesungguhnya</p>

			<b><h2>Kelas & Jadwal Belajar</h2></b>
		<p>
			Terdapat 3 jenis kelas: Regular (30 Jam), Intensive 1 (50 Jam), Intensive 2 (60 Jam)
Selamat kegiatan intensif, siswa belajar dari senin-jum’at dalam seminggu dengan jam pelajaran yang akan ditentukan oleh Best Partner Education yang tentu tidak akan mengganggu aktifitas siswa

		</p>
		</div>
		<div class="col-md-4 class-sidebar">
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/toefl/learning.png')); ?>">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>Task Based Learning</h3>
					<p>Menggunakan Metode Task Based Learning and Focus skill development</p>
				</div>
			</div>
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/toefl/Daily Opportunities.pn')); ?>g">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>Daily Opportunities</h3>
					<p>Siswa selalu mendapat daily opportunities sebagai sarana latihan intensif di luar jam pelajaran kelas</p>
				</div>
			</div>
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/toefl/Professional Tutor.png')); ?>">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>Professional Tutor</h3>
					<p>Di bimbing oleh tutor yang yang memiliki latar belakang pendidikan tinggi dalam Bahasa Inggris dan yang berpengalaman dengan Test TOEFL dan telah mengikuti tes TOEFL dan berhasil mendapat nilai minimal 550</p>
				</div>
			</div>

		</div>
	</div>

	<div class="col-md-12 target-wrapper" id="target" style="border-top:1px solid #ccc">
		<h1> Target Pembelajaran</h1>
		<div class="col-md-4 target tablink" onclick="openTabs(event,'listening')">
			<div class="target-header"><img src="<?php echo e(asset('/img/toefl/Listening Comprehension.png')); ?>">
			<p>Listening Comprehension</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12"> Siswa belajar memahami berbagai bentuk pertanyaan, tekanan dan nada, perbedaan bunyi, idiom, ungkapan-ungkapan percakapan, frase kata kerja, informasi tersirat, perbandingan, dan maksa/isi percakapan.</div>
			</div>
		</div>
		<div class="col-md-4 target tablink" onclick="openTabs(event,'reading')">
			<div class="target-header">
			<img src="<?php echo e(asset('/img/toefl/Structure and Written Expression.png')); ?>">
			<p>Structure and Written Expression</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12">Siswa berlatih  mengidentifikasi bahasa Inggris tulis yang digunakan dalam situasi formal. Siswa juga mengasah pengetahuan yang cukup tentang grammar dengan menentukan kalimat-kalimat mana yang paling efektif, dan benar dalam pengungkapan. </div>
			</div>
		</div>
		<div class="col-md-4 target tablink" onclick="openTabs(event,'writing')">
			<div class="target-header">
			<img src="<?php echo e(asset('/img/toefl/Reading.png')); ?>">
			<p>Reading Comprehension</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12">Siswa belajar untuk mengetahui pola-pola dan standard soal tertentu. Disini, siswa mengasah kemampuan dalam memahami, menginterpretasikan, dan menganalisis teks dan bacaan. </div>
			</div>
		</div>

	</div>
		<div class="col-md-12 learn-exp" id="learn-exp">
		<h1>Pengalaman Belajar</h1>
		<div class="learn-vid-wrapper col-md-12">
			<div class="col-md-4">
				<div class="col-md-12 learn-vid">
					<section class="videos-section">
			<div class="col-cont">
				<div class="youtube-container home-youtube-container embed-responsive embed-responsive-16by9 embed-responsive-item" id="videoPlayer">
					<div class="homeVideoThumbnail home-videoplayer" id="vid-0rXQ-nRYnP4"><img style="width:100%;" src="//img.youtube.com/vi/0rXQ-nRYnP4/0.jpg" />    <i class="fa fa-youtube-play homeVideoPlayButton"></i></div>

				</div>

			</div>
		</section>
		 <div class="video-desc" style="padding-top:5px;">IKIP TOEFL SIMULATION</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="col-md-12 learn-vid">
					<section class="videos-section">
			<div class="col-cont">
				<div class="youtube-container home-youtube-container embed-responsive embed-responsive-16by9 embed-responsive-item" id="videoPlayer">
					<div class="homeVideoThumbnail home-videoplayer" id="vid-18KGQSz4y-Q"><img style="width:100%;" src="//img.youtube.com/vi/18KGQSz4y-Q/0.jpg" />    <i class="fa fa-youtube-play homeVideoPlayButton"></i></div>

				</div>

			</div>
		</section>
		 <div class="video-desc" style="padding-top:5px;">Apa sih TOEFL itu??</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="col-md-12 learn-vid">
					<section class="videos-section">
			<div class="col-cont">
				<div class="youtube-container home-youtube-container embed-responsive embed-responsive-16by9 embed-responsive-item" id="videoPlayer">
					<div class="homeVideoThumbnail home-videoplayer" id="vid-VO1lVA1Lm7Q"><img style="width:100%;" src="//img.youtube.com/vi/VO1lVA1Lm7Q/0.jpg" />    <i class="fa fa-youtube-play homeVideoPlayButton"></i></div>

				</div>

			</div>
		</section>
		 <div class="video-desc" style="padding-top:5px;">TOEFL Simulation</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
$(document).ready(function(e) {
  $('.homeVideoThumbnail').click(function(test){
    var id = $(this).attr('id').replace('vid-', '');
    var title = $(this).children("span").html();
    var descrip = $(this).children("em").html();
    var vid = '<iframe src="//www.youtube.com/embed/' + id + '?autoplay=1" width="100%" height="200" frameborder="0" allowfullscreen></iframe>';
    if (typeof title != 'undefined') {
        var vid = vid + '<p>' + title + ' &mdash; <em>' + descrip + '</p>';
    }
    //$('#videoPlayer',this).html(vid);
$(this).parent().html(vid);
  });
});
function scroll_to(div){
	 $('html, body').animate({
        scrollTop: $("#"+div).offset().top - 230
    }, 1000);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_wo_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views//language/english/toefl-class.blade.php ENDPATH**/ ?>