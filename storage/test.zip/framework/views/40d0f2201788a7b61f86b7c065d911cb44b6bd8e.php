<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1" name="viewport" />
<meta name="viewport" content="initial-scale=1, maximum-scale=1, user-
  scalable=yes">

<!-- Primary Meta Tags -->
<meta name="title" content="<?php echo $__env->yieldContent('title'); ?>">
<title><?php echo $__env->yieldContent('title'); ?></title>

<meta name="description" content="Kami memberikan layanan dalam Persiapan IELTS ini sebagai solusi untuk pendidikan luar negeri.">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="<?php echo e(url()->current()); ?>">
<meta property="og:title" content="<?php echo $__env->yieldContent('news-title'); ?>">
<meta property="og:description" content="<?php echo $__env->yieldContent('news-desc'); ?>">
<meta property="og:image" content="<?php echo $__env->yieldContent('news-image'); ?>">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="<?php echo e(url()->current()); ?>">
<meta property="twitter:title" content="<?php echo $__env->yieldContent('news-title'); ?>">
<meta property="twitter:description" content="<?php echo $__env->yieldContent('news-desc'); ?>">
<meta property="twitter:image" content="<?php echo $__env->yieldContent('news-image'); ?>">

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/app.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bp108.css')); ?>">

	<link href="<?php echo e(asset('/css/toggle-nav9.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style media="screen">
  .btn-primary.disabled, .btn-primary:disabled{
    cursor:not-allowed;
  }
</style>
<script src="<?php echo e(asset('/js/jquery2.min.js')); ?>"></script>


<script src="<?php echo e(asset('/js/slick.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/toggle-nav.js')); ?>" type="text/javascript"></script>
	<script src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@12.0.0/dist/lazyload.min.js"></script>
  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-149158649-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-149158649-1');
</script>
<script type="text/javascript">
//document.addEventListener('contextmenu',event => event.preventDefault());
function mobile_menu(x){
  x.classList.toggle("change");
}
</script>
<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/includes/news-head.blade.php ENDPATH**/ ?>