
<style media="screen">

  .events-logo{
    display:block;
          max-width:100%;
    height:100px;margin:10px auto;
  }
  @media  screen and (max-width:480px){
    .events-logo-wrapper
    {
      width:50% !important;
    }
    .events-logo{

      height:75px !important;
    }
  }
</style>
<?php $__env->startSection('content'); ?>

<div class="content-wrapper col-md-12">

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
          <?php if(session()->has('message')): ?>

          <div class="alert alert-success" style="text-align:center">
            <?php echo session()->get('message'); ?> <br>

            <button type="button" class="btn btn-primary" onclick="close_alert()" name="button">Ok</button>
          </div>
          <?php endif; ?>
            <div class="card">
                <div class="card-header" style="text-align:center;">
                  <h3>E-Guest Book</h3>

                  <h5 style="text-transform:capitalize;margin-bottom:0;"><?php echo e($events->nama); ?></h5>
                </div>

                <div class="card-body">
                  <?php if(!empty($logo)): ?>

                  <div class="form-group row justify-content-center" style="padding-bottom:10px;">

                    <?php $__currentLoopData = $logo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-lg-3 events-logo-wrapper">

                  <img class="events-logo" src="<?php echo e(Storage::disk('events')->url($data_logo->lokasi_logo)); ?>" alt="">
                  </div>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>

                <?php endif; ?>

                    <form method="POST" action="<?php echo e(url('events/'.$events->kd.'/guest-book')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="event" value="<?php echo e($events->nama); ?>">
                        <input type="hidden" name="redirect_email" value="<?php echo e($events->redirect_email); ?>">
                        <input type="hidden" name="kd" value="<?php echo e($events->kd); ?>">
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Alamat E-Mail')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('No Telepon')); ?></label>

                            <div class="col-md-6">
                                <input style="text-align:lowercase;" id="no_telepon" type="no_telepon" class="form-control <?php if ($errors->has('no_telepon')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_telepon'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="no_telepon" value="<?php echo e(old('no_telepon')); ?>" required autocomplete="no_telepon">

                                <?php if ($errors->has('no_telepon')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_telepon'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <?php if($events->data_kelas == 1): ?>
                          <div class="form-group row">
                              <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Kelas')); ?></label>

                              <div class="col-md-6">
                                  <input id="kelas" type="text" class="form-control <?php if ($errors->has('kelas')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kelas'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="kelas" value="<?php echo e(old('kelas')); ?>" required autocomplete="kelas" autofocus>

                                  <?php if ($errors->has('kelas')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kelas'); ?>
                                      <span class="invalid-feedback" role="alert">
                                          <strong><?php echo e($message); ?></strong>
                                      </span>
                                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                              </div>
                          </div>

                        <?php endif; ?>
                        <div class="form-group row">
                            <div class="col-md-4">

                            </div>
                            <div class="col-md-8">
                              <div class="form-check-inline">

                                <input type="checkbox" name="agree" id="agree" class="form-check-input" value=""> <label class="form-check-label" for=""> Setuju dengan <a href="<?php echo e(url('/events/term-and-condition')); ?>" target="blank">Syarat & Ketentuan</a>

                              </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" id="submit" class="btn btn-primary" disabled>
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
    </div>
  </div>
</div>
</div>
<script type="text/javascript">
document.getElementById('agree').addEventListener('change', function() {
  if (this.checked) {
    document.getElementById('submit').disabled = false;
  } else {
    document.getElementById('submit').disabled = true;
  }
});
function close_alert() {
  $('.alert').hide();
}
$("document").ready(function(){
    setTimeout(function(){
       $("div.alert").remove();
    }, 5000 ); // 5 secs

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_wo_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/events/guest-book.blade.php ENDPATH**/ ?>