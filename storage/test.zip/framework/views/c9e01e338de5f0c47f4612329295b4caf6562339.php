<style media="screen">
    .loading-wrapper {
        width: 100vw;
        height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 9999999;
        display: none;
        background: rgba(255, 255, 255, 1);
    }

    .loading-wrapper img {
        display: block;
        margin: 0 auto;
        width: 500px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);

    }

    .form-group input[type=file] {
        position: relative !important;
        opacity: 1 !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="loading-wrapper">
    <img src="<?php echo e(asset('/img/loading.gif')); ?>" alt="">
</div>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title "><?php echo e(__('events')); ?></h4>
                        <p class="card-category"> <?php echo e(__('Here you can manage events')); ?></p>
                    </div>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="alert alert-success">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo e(session('status')); ?></span>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-12 text-right">
                                <a href="<?php echo e(route('admin-events.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add Events')); ?></a>
                            </div>
                        </div>
                        <?php echo csrf_field(); ?>
                        <div class="table-responsive">
                            <table class="table">
                                <colgroup>
                                    <col width="17.5%">
                                    <col>
                                    <col>
                                    <col width="25%">
                                    <col>
                                </colgroup>
                                <thead class=" text-primary">
                                    <th>
                                        <?php echo e(__('Nama')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('Preview Link')); ?>

                                    </th>
                                    <th>Jumlah Terdaftar</th>
                                    <th>
                                        <?php echo e(__('Durasi')); ?>

                                    </th>
                                    <th class="text-center">
                                        <?php echo e(__('Actions')); ?>

                                    </th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($data->nama); ?>

                                        </td>
                                        <td>
                                        <a href=" <?php echo e(url("/events/".$data->kd."/guest-book")); ?>">
                                          Form
                                        </a>
                                         |
                                        <a href=" <?php echo e(url("admin/events/data-guestbook/".$data->kd)); ?>">
                                          Data
                                        </a>
                                        </td>

                                        <td><?php echo e($data->jlh); ?></td>
                                        <td>
                                            <?php echo e($data->tgl_mulai.' '.$data->jam_mulai); ?>

                                          <?php if($data->tgl_selesai || $data->jam_selesai): ?>
                                            <br> to <br>
                                              <?php echo e($data->tgl_selesai.' '.$data->jam_selesai); ?>

                                          <?php endif; ?>
                        </div>
                        </td>
                        <td class="text-center">
                            <form action="<?php echo e(route('admin-events.destroy', $data)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>

                                <a rel="tooltip" class="btn btn-success btn-link" href="<?php echo e(route('admin-events.edit', $data)); ?>" data-original-title="" title="">
                                    <i class="material-icons">edit</i>
                                    <div class="ripple-container"></div>
                                </a>
                                <button type="button" class="btn btn-danger btn-link" data-original-title="" title="" onclick="confirm('<?php echo e(__("Are you sure you want to delete this events?")); ?>') ? this.parentElement.submit() : ''">
                                    <i class="material-icons">close</i>
                                    <div class="ripple-container"></div>
                                </button>
                            </form>
                        </td>
                        <!--   <td class="td-actions text-right">
                              <form action="<?php echo e(route('mp.destroy', $data)); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('delete'); ?>

                                  <a rel="tooltip" class="btn btn-success btn-link" href="<?php echo e(route('mp.edit', $data)); ?>" data-original-title="" title="">
                                    <i class="material-icons">edit</i>
                                    <div class="ripple-container"></div>
                                  </a>
                                  <button type="button" class="btn btn-danger btn-link" data-original-title="" title="" onclick="confirm('<?php echo e(__("Are you sure you want to delete this events?")); ?>') ? this.parentElement.submit() : ''">
                                      <i class="material-icons">close</i>
                                      <div class="ripple-container"></div>
                                  </button>
                              </form>
                         <a rel="tooltip" class="btn btn-success btn-link" href="<?php echo e(url('admin'.'/profile')); ?>" data-original-title="" title="">
                                <i class="material-icons">edit</i>
                                <div class="ripple-container"></div>
                              </a>
                          </td>-->
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>

                    </div>
                    <div class="row">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'events','activeMenu' => 'data-management', 'titlePage' => __('events')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/admin/events/index.blade.php ENDPATH**/ ?>