    <div class="col-md-2 logo-wrapper">
        <a href="/"><img src="<?php echo e(asset('/img/logo lama.png')); ?>" class="logo"></a>
    </div>
    <div class="col-md-10 nav-wrapper">
    	<ul class="nav">
            <li><a class="<?php echo e(Request::is('/') ? 'active' : ''); ?>" href="<?php echo e(url('')); ?>">Home</a>

            </li>
<li><a class="<?php echo e(Request::is('about_us') ? 'active' : ''); ?>" href="<?php echo e(url('/about_us')); ?>">About</a>
    <!--         <li class="dropdown"><a class="<?php echo e(Request::is('about_us') ? 'active' : ''); ?>" href="/about_us">About</a>
          <  	<div class="dropdown-content dropdown-content3">

           <span class="menu" ><a href="/about_us">Siapa Kami</a></span>
           <span class="menu" ><a href="/why_choose_us">Mengapa Kami</a></span>
           <span class="menu" ><a href="/bp_services">Layanan</a></span>

        <div class="col-md-6">
        	<h4>Best Partner Foundation</h4>
           <div class="menu" href="#">Siapa Kami</div>
           <div class="menu" href="#">Program BP Foundation</div>
           <div class="menu" href="#">Beasiswa BP Foundation</div>
        </div>

      </div>-->
            </li>
            <li><!--<a class="<?php echo e(Request::is('study_abroad') ? 'active' : ''); ?>" href="/study_abroad">Studying Abroad</a>-->
                <a class="<?php echo e(Request::is('study_abroad') ? 'active' : ''); ?>" href="<?php echo e(url('/study-abroad')); ?>">Studying Abroad</a>
            </li>
           <li class="dropdown">
                <a href="<?php echo e(url('/products')); ?>"  class="<?php echo e(Request::is('products') ? 'active' : ''); ?>" >Products</a>
             <div class="dropdown-content dropdown-content2">
                    <span class="dropdown" href="#"><a href="/products/language">Language</a>
                        <ul class="submenu">
                            <li class="dropdown2"><a href="/products/language/english">English</a>
                                <ul class="submenu" style="column-count:1;">
                                    <li><a href="/products/language/english/ielts-class">IELTS Class</a>

                                    </li>
                                    <li><a href="/products/language/english/toefl-class">TOEFL Class</a></li>
                                    <li><a href="/products/language/english/bep">BEP - General English Class</a></li>

                                   <!-- <li>Regular Class</li>
                                    <li>Intensive Class</li>-->

                                    <li><a href="/products/language/english/young-learners">Young Learners</a></li>
                                   <!-- <li>Teens</li>-->
                                    <li><a href="/products/language/english/gmat">GMAT</a></li>
                                    <li><a href="/products/language/english/gre">GRE</a></li>
                                    <li> <a href="/products/language/english/sat">SAT</a></li>
                                    <li> <a href="/products/language/english/pte">PTE</a></li>
                                    </ul>
                            </li>
                            <li><a href="/products/language/mandarin">Mandarin</a></li>
                            <li><a href="/products/language/french">French</a></li>
                            <li><a href="/products/language/german">German</a></li>
                            <li><a href="/products/language/korean">Korean</a></li>
                            <li><a href="/products/language/jaanese">Japanese</a></li>
                        </ul>
                    </span>
                  <!--  <span  class="dropdown2" >-->
                  <span class="dropdown">
                    <a href="/products/ielts-test">IELTS Test</a>
                        <ul class="submenu">
                            <li> <a href="/products/ielts-test/simulation">Simulation </a>  </li>
                            <li> <a href="/products/ielts-test/official">Official</a> </li>
                        </ul>

                    </span>
                    <span class="dropdown">
                    <a  href="/products/toefl-test">TOEFL ITP Test    </a>
                         <ul class="submenu" style="margin-top:95px;">
                            <li> <a href="/products/toefl-test/simulation">Simulation</a> </li>
                        </ul>

                    </span>
                    <span><a href="/products/tips-belajar">Tips Belajar</a></span>
                    <span> <a href="/products/tax-claim">Tax Claim</a> </span>
                    <span> <a href="/products/claim-insurance">Claim Insurance</a> </span>
             </div>
           <!--     <div class="dropdown-content1">
                    <div class="container">
      <div class="row">
        <div class="mega-menu-left">
          <h4>Products & Services</h4>
          <div class="menu submenu-lang" href="#"><a href="/products/language">Language</a></div>
          <div class="menu" href="#"> <a href="/products/tips">Tips Belajar Bahasa </a></div>
          <div class="menu" href="#"> <a href="/products/tips">Services </a></div>
        </div>
        <div class="mega-menu-right">
            <div class="submega-menu submenu-lang-content col-md-12">
                <h3>Language</h3>
                <div class="col-md-6">
                    <h4 style="text-align: center;">English</h4>
                    <div class="col-md-12" style="column-count: 2;">
                     <div class="menu"><a href="/products/toefl-ibt">TOEFL iBT</a></div>
                     <div class="menu"><a href="/products/toefl-itp">TOEFL ITP</a></div>
                     <div class="menu"><a href="/products/ielts-test">IELTS Test</a></div>
                     <div class="menu"><a href="/products/gmat">GMAT</a></div>
                     <div class="menu"><a href="/products/gre">GRE</a></div>
                     <div class="menu"><a href="/products/sat">SAT</a></div>
                     <div class="menu"><a href="/products/bep">BEP</a></div>

                     <div class="menu"><a href="/products/ylt">Young Learners & Teens</a></div>
                     <div class="menu"><a href="/products/reg-class">Regular Class</a></div>
                     <div class="menu"><a href="/products/int-class">Intensive Class</a></div>
                     <div class="menu"><a href="/products/ielts-class">IELTS Class</a></div>
                     <div class="menu"><a href="/products/toefl-class">TOEFL Class</a></div>
                     <div class="menu"><a href="/products/jadwal-ielts">Jadwal Tes IELTS</a></div>
                     <div class="menu"><a href="/products/jadwal-toefl">Jadwal Tes TOEFL</a></div>
                    </div>

                </div>
                <div class="col-md-3">
                    <h4>Japanese</h4>
                    <div class="menu" href="#">Upcoming</div>
                </div>
                <div class="col-md-3">
                    <h4>Others</h4>
                    <div class="menu" href="#">Upcoming</div>
                </div>
            </div>
        </div>
      </div>
      </div>
    </div>-->
            </li>
            	<li><a href="/careers">Careers</a></li>
            <li class="dropdown"><a class="<?php echo e(Request::is('media') ? 'active' : ''); ?>" href="#">Media</a>
            	<div class="dropdown-content">
            		 <span><a href="/media/news">News</a></span>
                     <span>   <a href="/media/events">Events</a></span>
                     <span> <a href="/media/testimony">Testimony</a></span>
      	      </div>
            </li>
          <!-- <li><a class="<?php echo e(Request::is('centres') ? 'active' : ''); ?>" href="/centres">Centres</a></li>-->
            <li><a class="<?php echo e(Request::is('contact_us') ? 'active' : ''); ?>" href="/contact_us">Contact Us</a></li>
            <li class="dropdown"> <a href="#" style="max-width: 170px;text-overflow: ellipsis;overflow: hidden;white-space: nowrap;display: block;"> <img src="<?php echo e(asset('/img').'/user.png'); ?>" style="width:30px;" alt="">
              <?php if(Auth::check()): ?>
                <?php if(Auth::user()->name != "Undefined"): ?>
                    <?php echo e(Auth::user()->name); ?>

                <?php endif; ?>
                User
          <?php else: ?>
            Guest
          <?php endif; ?>
          </a>
              <div class="dropdown-content">


                     <?php if(Auth::check()): ?>
                       <span> <a href="/logout">Logout</a> </span>
                     <?php else: ?>
                            <span><a href="<?php echo e(url('/login')); ?>">Login</a></span>
                        <span>   <a href="/register">Register</a></span>
                    <?php endif; ?>

              </div>
            </li>
            <!--<li><a href="/login">Login</a></li>-->
        </ul>
        <a href="#menu" onclick="mobile_menu(this)" class="menu-link active">
          <div class="bar1"></div>
          <div class="bar2"></div>
          <div class="bar3"></div>
        </a>
      	<nav id="menu" class="menu">
      		<ul class="level-1">
      			<li><a href="/">Home</a></li>
            	<li><a href="/about_us">About</a></li>
              	<li><a href="/study-abroad">Studying Abroad</a></li>
      			<li><a href="/products">Products</a><span class="has-subnav">&#x25BC;</span>
      				<ul class="wide level-2">
      					<li><a href="/products/language">Language</a><span class="has-subnav">&#x25BC;</span>
                  <ul class="level-3" style="padding-left:15px;">
                    <li><a href="/products/language/english">English</a><span class="has-subnav">&#x25BC;</span>
                      <ul class="level-4" style="padding-left:15px;">
                        <li><a href="/products/language/english/ielts-class">IELTS Class</a></li>
                        <li><a href="/products/language/english/toefl-class">TOEFL Class</a></li>
                        <li><a href="/products/language/english/bep">BEP - General English Class</a></li>
                        	<li><a href="/products/language/english/young-learners">Young Learners</a></li>
                          	<li><a href="/products/language/english/gmat">GMAT</a></li>
                            	<li><a href="/products/language/english/gre">GRE</a></li>
                              <li> <a href="/products/language/english/sat">SAT</a> </li>
                      </ul>
                    </li>
                    <li><a href="/products/language/mandarin">Mandarin</a></li>
                    <li><a href="/products/language/french">French</a></li>
                    	<li><a href="/products/language/german">German</a></li>
                      	<li><a href="/products/language/korean">Korean</a></li>
                        	<li><a href="/products/language/japanese">Japanese</a></li>
                  </ul>
                </li>
      					<li><a href="/products/ielts-test">IELTS Test</a></li>
      					<li><a href="/products/toefl-test">TOEFL ITP Test</a></li>
                	<li><a href="/products/tips-belajar">Tips Belajar</a></li>
                  <li> <a href="/products/tax-claim">Tax Claim</a> </li>
      				</ul>
      			</li>
      				<li><a href="/careers">Careers</a></li>
      			<li><a href="#">Media</a><span class="has-subnav">&#x25BC;</span>
      				<ul class="level-2">
      					<li><a href="/media/news">News</a></li>
      					<li><a href="/media/events">Events</a></li>
                <li><a href="/media/testimony">Testimony</a></li>
      				</ul>
      			</li>
      			<li><a href="/contact_us">Contact Us</a></li>
      		</ul>
      	</nav>
    </div>

      	<!-- /view -->

    <!--<div class="col-md-12 navbar-inner">

        <div class="col-md-9 nav-wrapper">

        </div>

    </div>-->
<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/includes/header.blade.php ENDPATH**/ ?>