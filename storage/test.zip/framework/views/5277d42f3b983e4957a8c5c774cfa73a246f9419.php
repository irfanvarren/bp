<head>
  <style media="screen">
  .wrapper{
        margin:100px auto;
        width:500px;

          display:block;
  }
  table{
    border-collapse: collapse;
    width:100%;

  }
  table tr, table td, table th{
    padding:8px;
    text-align:left;
    border:1px solid black
  }
    </style>
</head>
<h3>Data Kuesioner</h3>
<div class="wrapper">
<table>
  <tr>
    <td colspan="2">Data Responden</td>
  </tr>
  <tr>
    <td>Nama :</td><td> <?php echo e($email->nama); ?></td>
  </tr>
  <tr>
    <td>Tanggal Test : </td> <td><?php echo e($email->tgl_test); ?></td>
  </tr>
  <tr>
    <td>Email :</td> <td><?php echo e($email->email); ?></td>
  </tr>
</table>
 <br>
 <table>
<tr>
  <td colspan="2">Data Kuesioner</td>
</tr>
<?php for($i = 1; $i <= 3; $i++): ?>
  <tr>
  <?php
  $pertanyaan = 'q'.$i;
  $jawaban = 'a'.$i;
  ?>
  <?php if($jawaban == ''||$jawaban == NULL): ?>
    <?php
$jawaban= 'Null';
    ?>
  <?php endif; ?>
  <br>
<td><?php echo e($i.'. '); ?> <?php echo e($email->$pertanyaan); ?></td> <td><?php echo e($email->$jawaban); ?></td>

</tr>
<?php endfor; ?>

</table>
</div>
<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/email/ielts-questionnaire.blade.php ENDPATH**/ ?>