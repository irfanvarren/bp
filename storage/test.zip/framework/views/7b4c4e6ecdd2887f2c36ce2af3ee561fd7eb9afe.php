
<style media="screen">
  .news-tag-desc{
    padding:15px;
    font-family:"calibri";
    color:#313131;
  }
  .news-tag-desc p{
    line-height:18px;
    font-size:16px;
  }
  .news-tag-title{
    line-height:25px;
  }
  .news-tag-wrapper .news-bg-img{
    margin-bottom:0;
  }
  .news-tag-wrapper{
    border-radius:8px;
    margin-bottom:20px;
    background:white;

    box-shadow:0px 0px 2px #bcbcbc;
  }
  .news-bg-img{
    height:170px !important;
    background-position: top left !important;
  }

  @media  screen and (max-width:480px){
    .news-tag.content-wrapper{
      padding:30px;
    }
    .news-tag-center{
      padding:15px;
    }
  }
</style>
<?php $__env->startSection('title','#'.$tag.' | Best Partner'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12 content-wrapper news-tag">
  <div class="row justify-content-center">
    <div class="col-md-10 news-tag-center">

      <div class="row">

        <div class="col-md-8">
          <div class="row">


            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="<?php echo e(url("media/news/".$data_news->created_at->format("Y/m/").$data_news->slug)); ?>">
            <div class="col-md-12 news-tag-wrapper">
              <div class="row">
                <div class="col-md-4 news-tag-img">
                  <div class="row">


                  <div class="col-md-12 news-bg-img" style="background-image:url(' <?php echo e(Storage::disk('news')->url($data_news->image)); ?>');">
                  </div>
                </div>

                </div>

                <div class="col-md-8 news-tag-desc">
                  <span style="font-family:"><?php echo e($data_news->created_at->format("l, d M Y H:i")); ?></span>
                    <h3 class="news-tag-title"><?php echo e(ucwords($data_news->title)); ?></h3>
                    <p class="">
                  <?php echo str_limit(strip_tags($data_news->body),180,$end = "..."); ?>

                </p>
                </div>
                </div>
            </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
    <?php echo $__env->make('includes.news-sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_wo_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/news-tags.blade.php ENDPATH**/ ?>