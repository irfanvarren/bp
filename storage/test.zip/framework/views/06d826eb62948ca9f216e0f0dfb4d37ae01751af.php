
<?php $__env->startSection('title', 'Careers'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12 content-wrapper">
  <div class="col-md-6 careers-img" style="background-image:url('<?php echo e(asset('/img/career.png')); ?>')">
  </div>
  <div class="col-md-6 careers-desc">
    <div >

    <h2><strong>Join Us</strong></h2>
    <p>Bagi kamu yang tertarik menjadi seorang tenaga pendidik yang memiliki kar    ir cemerlang bergabunglah dengan Best Partner Education. Mengajar di Best Partner Education, kami pastikan anda memiliki jenjang karir yang membawa anda kepada masa depan yang lebih baik.

Sebelum itu, daftarkan dulu diri anda dan ikuti seleksi kami terlebih dahulu di link di bawah ini. <br>

     </p>
    <a href="<?php echo e(url('/careers/application')); ?>">  <button type="button" name="button">Apply Now</button></a>
         </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_wo_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views//careers.blade.php ENDPATH**/ ?>