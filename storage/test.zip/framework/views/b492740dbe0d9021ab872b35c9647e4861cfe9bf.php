

<?php $__env->startSection('content'); ?>
<div class="col-md-12 content-wrapper">
  <?php if(session()->has('message')): ?>
  <div class="alert alert-success" style="text-align:center">
    <?php echo session()->get('message'); ?> <br>

    <button type="button" class="btn btn-primary" onclick="close_alert()" name="button">Ok</button>
  </div>
  <?php endif; ?>
  <div class="col-md-12" style="text-align:center;margin-bottom:25px;">

    <h2>Form Pendaftaran Simulasi TOEFL</h2>
    <p>Info Lebih lanjut dapat menghubungi no WA di bawah ini:
    <ol style="list-style-position:inside">
      <li>+62 895 1513 9224 (Gerald)</li>
      <li>+62 858 2101 2006 (Lemuel)</li>
    </ol>
    </p>
  </div>
<form action="<?php echo e(url('products/toefl-test/simulation')); ?>" method="post">
  <?php echo e(csrf_field()); ?>

<div class="col-md-12">
  <div class="col-md-6">
<span class="col-md-4" style="padding:0;">Pilih Tanggal Simulasi :</span>
<div class="col-md-8" style="padding:0">

  <input type="date" class="form-control" name="tgl_simulasi" required value="">
</div>
</div>
  <div class="col-md-6">
<p class="col-md-4" style="padding:0"> Pilih Cabang Best Partner</p>
<p class="col-md-8" style="padding:0;">
<select class="form-control" name="cabang" required>
<option value="">- Pilih Cabang -</option>
<option value="Pontianak">Pontianak</option>
<option value="Singkawang">Singkawang</option>
</select>
</p>
  </div>
  </div>
  <div class="col-md-12">
    <p class="col-md-6">
      <input type="text" class="form-control" placeholder="Nama Lengkap" name="nama" value="" required>
    </p>
    <p class="col-md-6">
      <input type="email" class="form-control" name="email" value="" placeholder="Email" required>
    </p>
  </div>
  <div class="col-md-12">
    <p class="col-md-6">
        <input type="text" name="tempat_kelahiran" class="form-control" placeholder="Tempat Kelahiran" required value="">
    </p>
    <div class="col-md-6">
      <div class="row">
      <p class="col-md-4">
<input type="text" name="tgl_lahir" class="form-control" placeholder="Tanggal (dd)" pattern="[0-9]{2}" required value="">
     Tanggal Lahir
</p>
<p class="col-md-4">
  <select class="form-control" name="bulan_lahir" required>
    <option value="">Bulan (mm)</option>
    <option value="01">Januari</option>
      <option value="02">Februari</option>
        <option value="03">Maret</option>
          <option value="04">April</option>
            <option value="05">Mei</option>
              <option value="06">Juni</option>
                <option value="07">Juli</option>
                  <option value="08">Agustus</option>
                  <option value="09">September</option>
                    <option value="10">Oktober</option>
                      <option value="11">November</option>
                      <option value="12">Desember</option>


  </select>
</p>
<p class="col-md-4">
  <input type="text" class="form-control" name="tahun_lahir" placeholder="Tahun (yyyy)" pattern="[0-9]{4}" value="" required>
</p>
      </div>

      </div>
  </div>
  <div class="col-md-12">
    <p class="col-md-6">
      <input type="text" class="form-control" name="no_hp" placeholder="No. HP" value="" required pattern="[0-9]{10,13}">
    </p>
    <p class="col-md-6">
      <input type="text" class="form-control" placeholder="NIK" name="nik" value="" pattern="[0-9]{16}" required>
    </p>
  </div>
  <div class="col-md-12">
    <p class="col-md-6">
      <textarea rows="3" name="alamat" rows="3" class="form-control" required placeholder="Alamat"></textarea>
    </p>
    <p class="col-md-6">
      <textarea name="tujuan" rows="3" class="form-control" placeholder="Tujuan Mengikuti Simulasi TOEFL" required></textarea>
    </p>
  </div>
  <div class="col-md-12">

    <p class="col-md-12">
      <input type="submit" name="" value="Submit" class="btn btn-primary">
    </p>
  </div>
</form>
</div>
<script type="text/javascript">
  function close_alert(){
    $('.alert').hide();
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_wo_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views//language/toefl-simulation.blade.php ENDPATH**/ ?>