<?php $__env->startSection('title', 'Contact Us'); ?>

<style media="screen">
input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
	.contact-form input[type="text"],.contact-form input[type="number"],.contact-form input[type="email"]{
		border:none;
		background:none;
		color:white;
		padding:5px 0;
		outline:none;
		border-bottom:2px solid white;
	}
	.contact-form input:focus{
border:none;
	border-bottom:2px solid white;
	  box-shadow: inset 0 -1px 0 #ddd;
		outline:none !important;
	}
	.contact-form input[type="submit"]{
		color:#3e6db8;
		font-weight:bold;
		border-radius:30px;
		background:white;
	}

	.contact-form{
		color:white;
			padding:30px !important;
		background:#3e6db8;
	}
	.contact-form input::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */
  color:#dde3eb;
  opacity: 1; /* Firefox */
}
</style>
<?php $__env->startSection('content'); ?>
<div class="col-md-12 contact-wrapper">
	<div class="col-md-12">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success" style="text-align:center">
      <?php echo session()->get('message'); ?> <br>

      <button type="button" class="btn btn-primary" onclick="close_alert()" name="button">Ok</button>
    </div>
    <?php endif; ?>
		<h2>Contact Us</h2>
		<p>Jika anda memiliki pertanyaan	 mengenai program dan acara BP silahkan isi form dibawah ini, staf kami akan segera menghubungi anda kembali.</p>
		<!--<p>No Telpon : (0561) 8172583</p>
		<div><span class="col-md-1" style="padding:0;">WA : </span>

			<span class="col-md-11" style="padding:0;">
			<ul class="dash-list">
				<li>+62 895-1513-9224</li>
				<li>+62 858-2101-2006</li>
			</ul>
		</span> </div>-->


		</div>
		<div class="col-md-12 contact-form">
			<form class="" action="<?php echo e(url('/contact_us')); ?>" method="post">
				<?php echo e(csrf_field()); ?>

				<p>
					<label>Nama Lengkap</label> <br>
					<input class="form-control" type="text" name="nama" placeholder="Nama Lengkap" value="" required>
				</p>
				<p>
					<label>Email</label> <br>
					<input class="form-control" type="email" name="email" placeholder="Email" value="" required>
				</p>
				<p>
					<label>No Telpon / WA</label> <br>
					<input class="form-control" type="number" name="no_telepon" value="" placeholder="No Telpon" required>
				</p>
				<p>
					<label>Pesan :</label> <br>
					<textarea class="form-control" name="pesan" placeholder="Pesan..." wrap="soft" style="resize:none;" rows="5" required></textarea>
				</p>
				<input type="submit" class="btn btn-primary" style="float:right;padding:8px 40px;" name="submit" value="Submit">
			</form>

		</div>
</div>

<div class="col-md-12 centres-container">


	<div class="col-md-6">
		<h1  class="location-title">Best Partner Education - Pontianak</h1>
		<div class="maps-info col-md-12">
			<p>Jl. Prof. DR. Hamka, Sungai Jawi, Kec. Pontianak Kota, Kota Pontianak, Kalimantan Barat 78244</p>
		<p>(0561) 8172583</p>
		</div>
		<div class="jam-buka-wrapper col-md-11">

			<table class="table-jam-buka">
				<caption>Jam Buka</caption>
					<tr>
						<td>Senin</td> <td>08.00 – 21.00</td>
					</tr>
					<tr>
						<td>Selasa</td> <td>08.00 – 21.00</td>
					</tr>
					<tr>
						<td>Rabu</td> <td>08.00 – 21.00</td>
					</tr>
					<tr>
						<td>Kamis</td> <td>08.00 – 21.00</td>
					</tr>
					<tr>
						<td>Jumat</td> <td>08.00 – 21.00</td>
					</tr>
					<tr>
						<td>Sabtu</td> <td>08.00 – 19.00</td>
					</tr>
					<tr>
						<td>Minggu</td> <td>Tutup</td>
					</tr>

			</table>
				</div>




	</div>
	<div class="col-md-6 map-wrapper">
      <iframe class="map col-md-12" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.818000937931!2d109.32262601475328!3d-0.022926199983269144!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e1d58f6b4ce8ba3%3A0x2135d78ecb306a81!2sLes+Bahasa+Inggris+(Best+Partner+Education)!5e0!3m2!1sen!2sid!4v1564730700383!5m2!1sen!2sid"  frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/contact_us.blade.php ENDPATH**/ ?>