
<?php $__env->startSection('title', 'BEP'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12 content-header" style="/*background-image: linear-gradient(to bottom right, #244272,#99c0ff);*/background-image:url('<?php echo e(asset('/img/bep.jpg')); ?>');">
	<div style="background-image: linear-gradient(to bottom right, #1c4e9e,#74bff2);width: 100%;height: 100%;position: absolute;top:0;left: 0;z-index: 1;opacity: 0.7;"></div>
		<div class="content-title" >
	<p><h1>BEP (Best Education Programme)</h1></p>
	<p>General English Class</p>
	<a href="https://wa.me/6283151281946" target="_blank" class="content-btn"> Daftarkan Sekarang</a>
	</div>
</div>
<div class="col-md-12 content-wrapper class-content-wrapper">
	<div class="col-md-12 content-nav">
		<nav>
			<a onclick="scroll_to('deskripsi')">
				Deskripsi
			</a>
			<a onclick="scroll_to('learn-exp')">
				Pengalaman Belajar
			</a><!--
			<a onclick="scroll_to('target')">
				Target Belajar
			</a>-->
		</nav>
	</div>
	<div class="col-md-12 class-content" id="deskripsi">
		<div class="col-md-8" style="padding:0;">
		<h2>About This Program</h2>
		<p>General English Class dirancang khusus untuk jenjang sekolah menengah hingga dewasa. Tahapan belajar kalian dibagi menjadi 4 level yang membantu kalian mengembangkan kemampuan berbahasa Inggris dari dasar hingga maksimal. Kalian juga akan dibimbing dengan tutor yang tersertifikasi dan profesional di bidangnya. Pembelajaran di setiap sesinya juga dikemas dengan metode dan teknik yang komunikatif dan terfokus pada pengembangan kemampuan berbahasa.</p>
		<h2>Level Kelas dan Jadwal Belajar</h2>
		<p>Program ini menawarkan kelas intensif dengan 5 pertemuan dalam seminggu (Senin-Jumat) dan tiap pertemuan berlangsung selama 90 menit. Program ini membagi proses pembelajaran kalian menjadi 4 tahapan level yang berkelanjutan (Elementary, Pre-intermediate, Intermediate, dan Upper-intermediate).</p>
		</div>
		<div class="col-md-4 class-sidebar">
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/bep/Pelatihan dari dasar hingga mahir.png')); ?>">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>Pelatihan dari dasar hingga mahir</h3>
					<p>Program ini berfokus pada pengembangan kemampuan berbahasa Inggris mendasar hingga mahir secara komunikatif dan praktikal.</p>
				</div>
			</div>
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/bep/Sistematis.png')); ?>">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>Sistematis</h3>
					<p>Struktur program yang sistematis dan dapat memaksimalkan proses belajar bahasa kalian dari awal hingga akhir program.</p>
				</div>
			</div>
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/bep/Bimbingan Praktek.png')); ?>">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>Bimbingan Praktek</h3>
					<p>Tiap sesinya kalian akan difasilitasi dengan bimbingan untuk mempraktikkan langsung kemampuan bahasa kalian di dalam kelas secara maksimal.</p>
				</div>
			</div>
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/bep/Up to Date.png')); ?>">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>Up to Date</h3>
					<p>Program juga dilengkapi dengan metode pengajaran yang up-to-date dengan perkembangan dunia pendidikan dan materi ajar yang sesuai dengan kebutuhan kalian untuk kompeten dalam berbahasa Inggris.</p>
				</div>
			</div>

		</div>
	</div>
<!--
	<div class="col-md-12 target-wrapper" id="target" style="border-top:1px solid #ccc">
		<h1> Target Pembelajaran</h1>
		<div class="col-md-3 target tablink" onclick="openTabs(event,'listening')">
			<div class="target-header"><img src="/img/listening2.png">
			<p>Listening</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12"> Dapat memahami ide utama dari sebuah pembicaraan baik monolog maupun dialog dengan topik yang beragam.</div>
				<div class="col-md-12"> Dapat memahami informasi factual yang spesifik yang ada pada sebuah dialog ataupun monolog.</div>
				<div class="col-md-12"> Dapat mengenal tipe soal yang diujikan di tes resmi dan memahami cara pengerjaan tiap tipe soal.</div>
			</div>
		</div>
		<div class="col-md-3 target tablink" onclick="openTabs(event,'reading')">
			<div class="target-header">
			<img src="/img/reading2.png">
			<p>Reading</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12">Dapat secara cepat dan tepat mencari jawaban untuk setiap jenis pertanyaan di tiap section. </div>
				<div class="col-md-12">Dapat memahami kosakata berlevel akademik untuk mempermudah kalian menjawab soal pada reading section.</div>
				<div class="col-md-12">Membiasakan siswa untuk membaca dan memahami instruksi soal reading section dengan benar dan tepat.</div>
			</div>
		</div>
		<div class="col-md-3 target tablink" onclick="openTabs(event,'writing')">
			<div class="target-header">
			<img src="/img/writing2.png">
			<p>Writing</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12">Mengetahui standar penulisan yang digunakan pada Writing Task 1 dan Writing Task 2.</div>
				<div class="col-md-12">Mengetahui strategi pengerjaan dan standar penilaian writing test pada IELTS Official Test.</div>
				<div class="col-md-12">Mendapatkan kosakata yang relevan yang mendukung untuk hasil tulisan yang baik. </div>
				<div class="col-md-12">Mendapatkan contoh penulisan yang baik beserta dengan criteria dan penjelasan masing-masing contoh secara rinci.</div>
			</div>
		</div>
		<div class="col-md-3 target tablink" onclick="openTabs(event,'speaking')">
			<div class="target-header">
			<img src="/img/speaking2.png">
			<p>Speaking</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12">Memahami sistem penilaian pada semua speaking task yang diujikan.</div>
				<div class="col-md-12">Mendapatkan tips dan trick untuk menjawab pertanyaan dan menyelesaikan tiap task yang diujikan.</div>
				<div class="col-md-12">Mendapatkan kosakata yang relevan dalam menjawab tiap pertanyaan yang diujikan.</div>
			</div>
		</div>
	</div>-->
		<div class="col-md-12 learn-exp" id="learn-exp">
		<h1>Pengalaman Belajar</h1>
		<div class="learn-vid-wrapper col-md-12">
			<div class="col-md-4">
				<div class="col-md-12 learn-vid">
					<video width="100%" height="90%" controls>
  <source src="<?php echo e(asset('/video/evolution_hospitality.mp4')); ?>" type="video/mp4">
Your browser does not support the video tag.
</video>
					<div class="video-desc">
						Deskripsi Video
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="col-md-12 learn-vid">
					<video width="100%" height="90%" controls>
  <source src="<?php echo e(asset('/video/evolution_hospitality.mp4')); ?>" type="video/mp4">
Your browser does not support the video tag.
</video>
					<div class="video-desc">
						Deskripsi Video
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="col-md-12 learn-vid">
					<video width="100%" height="90%" controls>
  <source src="<?php echo e(asset('/video/evolution_hospitality.mp4')); ?>" type="video/mp4">
Your browser does not support the video tag.
</video>
					<div class="video-desc">
						Deskripsi Video
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
function scroll_to(div){
	 $('html, body').animate({
        scrollTop: $("#"+div).offset().top - 230
    }, 1000);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_wo_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views//language/english/bep.blade.php ENDPATH**/ ?>