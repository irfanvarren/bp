<div class="sidebar" data-color="orange" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an imag e using data-image tag
  -->
  <div class="logo">
    <a href="<?php echo e(route('admin-dashboard')); ?>" class="simple-text logo-normal">
      <?php echo e(__("Admin")); ?>

    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/admin')); ?>">
          <i class="material-icons">dashboard</i>
          <p><?php echo e(__('Dashboard')); ?></p>
        </a>
      </li>

      <li class="nav-item <?php echo e(($activePage == 'cms' || $activePage == 'content-management') ? ' active' : ''); ?>">
        <a class="nav-link" data-toggle="collapse" href="#cms" aria-expanded="true">
          <i class="material-icons">widgets</i>
          <p><?php echo e(__('Website Contents')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse <?php echo e(($activeMenu == 'users-management') ? 'show' : ''); ?>" id="cms">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'users' ? ' active' : ''); ?>">
              <a class="nav-link" data-toggle="collapse" href="#test" aria-expanded="true">
                <span class="sidebar-mini"> H </span>
              <span class="sidebar-normal"><?php echo e(__('Home')); ?>   <b class="caret"></b></span>


              </a>
                  <div class="collapse <?php echo e(($activeMenu == 'content-management') ? 'show' : ''); ?>" id="test">
                    <ul class="nav">
                      <li class="nav-item<?php echo e($activePage == 'banner' ? ' active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('admin/banner')); ?>">
                          <span class="sidebar-mini"> B </span>

                            <span class="sidebar-normal"><?php echo e(__('Banner')); ?> </span>
                        </a>
                      </li>
                      <li class="nav-item<?php echo e($activePage == 'destination' ? ' active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('admin/users')); ?>">
                          <span class="sidebar-mini"> D </span>

                            <span class="sidebar-normal"><?php echo e(__('Destination')); ?> </span>
                        </a>
                      </li>
                      <li class="nav-item<?php echo e($activePage == 'wwd' ? ' active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('admin/users')); ?>">
                          <span class="sidebar-mini"> WWD </span>

                            <span class="sidebar-normal"><?php echo e(__('What We Do ?')); ?> </span>
                        </a>
                      </li>
                  </div>
            </li>
            <li class="nav-item<?php echo e($activePage == 'products' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/products')); ?>">
                <span class="sidebar-mini"> PR </span>

                  <span class="sidebar-normal"><?php echo e(__('Products')); ?> </span>
              </a>
            </li>

          </ul>
        </div>
      </li>
      <li class="nav-item <?php echo e(($activePage == 'users' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" data-toggle="collapse" href="#user-menu" aria-expanded="true">
          <i class="material-icons">person</i>
          <p><?php echo e(__('User')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse <?php echo e(($activeMenu == 'users-management') ? 'show' : ''); ?>" id="user-menu">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'users' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/users')); ?>">
                <span class="sidebar-mini"> U </span>
                <span class="sidebar-normal"><?php echo e(__('Users')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'profile' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/profile')); ?>">
                <span class="sidebar-mini"> UP </span>
                <span class="sidebar-normal"><?php echo e(__('User profile')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'roles' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/roles')); ?>">
                <span class="sidebar-mini"> UR </span>
                <span class="sidebar-normal"><?php echo e(__('User Roles')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'access' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/user-access')); ?>">
                <span class="sidebar-mini"> UA </span>
                <span class="sidebar-normal"><?php echo e(__('User Access')); ?> </span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item <?php echo e(($activePage == 'english-regis' || $activePage == 'data-management') ? ' active' : ''); ?>">
        <a class="nav-link" data-toggle="collapse" href="#laravelExample" aria-expanded="true">
          <i><img style="width:25px" src="<?php echo e(asset('material')); ?>/img/laravel.svg"></i>
          <p><?php echo e(__('Data')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse <?php echo e(($activeMenu == 'data-management') ? 'show' : ''); ?>" id="laravelExample">
          <ul class="nav">

            <li class="nav-item<?php echo e($activePage == 'english-regis' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/english-regis')); ?>">
                <span class="sidebar-mini"> ER </span>
                <span class="sidebar-normal"><?php echo e(__('English Registration')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'ielts-regis' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/ielts-regis')); ?>">
                <span class="sidebar-mini"> IR </span>
                <span class="sidebar-normal"><?php echo e(__('IELTS Registration')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'ielts-simulation' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/ielts-simulation')); ?>">
                <span class="sidebar-mini"> IS </span>
                <span class="sidebar-normal"><?php echo e(__('IELTS Simulation')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'toefl-regis' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/toefl-regis')); ?>">
                <span class="sidebar-mini"> TR </span>
                <span class="sidebar-normal"><?php echo e(__('TOEFL Registration')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'toefl-simulation' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/toefl-simulation')); ?>">
                <span class="sidebar-mini"> TS </span>
                <span class="sidebar-normal"><?php echo e(__('TOEFL Simulation')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'contact-us' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/contact-us')); ?>">
                <span class="sidebar-mini"> CU </span>
                <span class="sidebar-normal"><?php echo e(__('Contact Us')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'portfolio' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/portfolio')); ?>">
                <span class="sidebar-mini"> PO </span>
                <span class="sidebar-normal"><?php echo e(__('Portfolio')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'events' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/events')); ?>">
                <span class="sidebar-mini"> Ev </span>
                <span class="sidebar-normal"><?php echo e(__('Events')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'news' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/news')); ?>">
                <span class="sidebar-mini"> N </span>
                <span class="sidebar-normal"><?php echo e(__('News')); ?> </span>
              </a>
            </li>
              <li class="nav-item<?php echo e($activePage == 'testimony' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('admin/testimony')); ?>">
                  <span class="sidebar-mini"> T </span>
                  <span class="sidebar-normal"><?php echo e(__('Testimony')); ?> </span>
                </a>
              </li>

            <li class="nav-item<?php echo e($activePage == 'merchant' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(url('admin/merchant')); ?>">
                <span class="sidebar-mini"> M </span>
                <span class="sidebar-normal"><?php echo e(__('Merchant')); ?> </span>
              </a>
            </li>

          </ul>
        </div>
      </li>
    </ul>
  </div>
</div>
<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/layouts/navbars/sidebar-admin.blade.php ENDPATH**/ ?>