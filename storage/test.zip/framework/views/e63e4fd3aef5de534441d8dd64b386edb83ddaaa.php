
<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('content'); ?>
<!--<div class="products_services content-heamedia.blade.phpder col-md-12" style="background-image:url('/img/australia.jpg');">
	<h1>Products & Services</h1>
</div>-->
<div class="content-wrapper products-content col-md-12" >
<!--	<div class="col-md-12">
	<div class="best-product col-md-12" >

		<div class="col-md-6 best-product-image" style="background-image:url('/img/language.jpg');">
 
		</div>
		<div class="col-md-6 best-product-desc">
			<div class="col-md-12">

			<h1>IELTS PREPARATION CLASS</h1>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			</div>
		</div>
		</div>
	</div>-->
	<div class="col-md-12 products-wrapper">
		<a href="/products/language">
		<div class="col-md-3">
			<div class="col-md-12 product">
				<div class="col-md-12 product-top" style="background-image: url('<?php echo e(asset('/img/l.png')); ?>')">

				</div>
				<div class="col-md-12 product-bottom">
						<h1>Language</h1>
				</div>
			</div>
		</div>
		</a>
		<a href="/products/ielts-test">
		<div class="col-md-3">
			<div class="col-md-12 product">
				<div class="col-md-12 product-top" style="background-image: url('<?php echo e(asset('/img/et.png')); ?>')">

				</div>
				<div class="col-md-12 product-bottom">
						<h1>IELTS Test</h1>
				</div>
			</div>
		</div>
		</a>
		<a href="/products/toefl-test">
		<div class="col-md-3">
			<div class="col-md-12 product">
				<div class="col-md-12 product-top" style="background-image: url('<?php echo e(asset('/img/tt.png')); ?>')">

				</div>
				<div class="col-md-12 product-bottom">
						<h1>TOEFL Test</h1>
				</div>
			</div>
		</div>
		</a>
		<a href="/products/tips-belajar">
		<div class="col-md-3">
			<div class="col-md-12 product">
				<div class="col-md-12 product-top" style="background-image: url('<?php echo e(asset('/img/tb.png')); ?>')">

				</div>
				<div class="col-md-12 product-bottom">
						<h1>Tips Belajar</h1>
				</div>
			</div>
		</div>
		</a>


	</div>
</div>
<!--<div class="content-wrapper products_services-wrapper col-md-12">
	<div class="col-md-6 products_services-img" style="background-image:url('/img/products_services3.jpg');">

	</div>
	<div class="col-md-6 products_services-desc">
		<h2>Kelas Pelatihan IELTS</h2>
		<p>Kami memberikan pelatihan persiapan Tes IELTS dengan harga terjangkau, kualitas guru yang profesional dan tersertifikasi IELTS Minimal 7</p>
		<p>
			Kelas yang kami berikan meliputi :
			<ol class="col-md-12">
				<li>Durasi kelas dengan total mulai dari 30, 50 dan 60 jam dengan minimal 1,5 jam per pertemuan</li>
				<li>IELTS Prediction Test</li>
			</ol>
		</p>
	</div>
</div>
<div class="content-wrapper products_services-wrapper col-md-12">

	<div class="col-md-6 products_services-desc">
		<h2>Kelas Pelatihan IELTS</h2>
		<p>Kami memberikan pelatihan persiapan Tes IELTS dengan harga terjangkau, kualitas guru yang profesional dan tersertifikasi IELTS Minimal 7</p>
		<p>
			Kelas yang kami berikan meliputi :
			<ol class="col-md-12">
				<li>Durasi kelas dengan total mulai dari 30, 50 dan 60 jam dengan minimal 1,5 jam per pertemuan</li>
				<li>IELTS Prediction Test</li>
			</ol>
		</p>
	</div>
	<div class="col-md-6 products_services-img" style="background-image:url('/img/products_services2.jpg');">

	</div>
</div>
<div class="content-wrapper products_services-wrapper col-md-12">
	<div class="col-md-6 products_services-img" style="background-image:url('/img/products_services1.jpg');">

	</div>
	<div class="col-md-6 products_services-desc">
		<h2>Kelas Pelatihan IELTS</h2>
		<p>Kami memberikan pelatihan persiapan Tes IELTS dengan harga terjangkau, kualitas guru yang profesional dan tersertifikasi IELTS Minimal 7</p>
		<p>
			Kelas yang kami berikan meliputi :
			<ol class="col-md-12">
				<li>Durasi kelas dengan total mulai dari 30, 50 dan 60 jam dengan minimal 1,5 jam per pertemuan</li>
				<li>IELTS Prediction Test</li>
			</ol>
		</p>
	</div>
</div>
<div class="content-wrapper products_services-wrapper col-md-12">

	<div class="col-md-6 products_services-desc">
		<h2>Kelas Pelatihan IELTS</h2>
		<p>Kami memberikan pelatihan persiapan Tes IELTS dengan harga terjangkau, kualitas guru yang profesional dan tersertifikasi IELTS Minimal 7</p>
		<p>
			Kelas yang kami berikan meliputi :
			<ol class="col-md-12">
				<li>Durasi kelas dengan total mulai dari 30, 50 dan 60 jam dengan minimal 1,5 jam per pertemuan</li>
				<li>IELTS Prediction Test</li>
			</ol>
		</p>
	</div>
	<div class="col-md-6 products_services-img" style="background-image:url('/img/products_services3.jpg');">

	</div>
</div>-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_wo_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/products.blade.php ENDPATH**/ ?>