
<?php $__env->startSection('title', 'About Us'); ?>
<?php $__env->startSection('content'); ?>
<!--
<div class="content-header col-md-12" style="background-image:url('/img/bp_services.jpg');">
	<h1>Our Services</h1>
</div>
-->
<div class="content-wrapper language-content col-md-12" >
	<div class="col-md-12 product">
		<span class="product-title">IELTS Class</span>
		<div class="col-md-5 product-img" style="background-image: url('<?php echo e(asset('/img/ielts.jpg')); ?>');">
		</div>
		<div class="col-md-7 product-desc">
			<p>Program IELTS (Academic & General Training) dirancang untuk mempersiapkan kalian untuk meraih tes skor yang kalian inginkan. Kalian juga akan dibimbing oleh tutor yang berpengalaman dengan tes IELTS dan telah tersertifikasi (IELTS) dengan nilai minimal 7 (good language user). Metode pengajaran yang digunakan ampuh untuk membantu kalian mencapai target nilai yang memuaskan.
		</p>
			<p><b>Lokasi: </b> Pontianak, Singkawang, Ketapang</p>
			<div class="col-md-12" style="padding:0;">
				<button class="product-btn" onclick="location.href='/products/language/english/ielts-class'">Read More</button>
			</div>
		</div>
	</div>
	<div class="col-md-12 product">
		<span class="product-title">TOEFL Class</span>
		<div class="col-md-5 product-img" style="background-image: url('<?php echo e(asset('/img/toefl.jpg')); ?>');">
		</div>
		<div class="col-md-7 product-desc">
			<p>Program ini sangat cocok untuk siswa yang tengah mempersiapkan diri untuk menghadapi Test resmi PBT (ITP-TOEFL). Siswa BP sendiri, akan mempelajari secara intensif bentuk tes dalam PBT (ITP-TOEFL)mulai dari Listening Comprehension, Structure dan written expression, Reading comprehension dan strategi untuk menjawab. Setiap siswa akan belajar menggunakan materi tes-tes TOEFL otentik yang mirip dengan tes sesungguhnya
		</p>
			<p><b>Lokasi: </b> Pontianak, Singkawang, Ketapang</p>
			<div class="col-md-12" style="padding:0;">
				<button class="product-btn" onclick="location.href='/products/language/english/toefl-class'">Read More</button>
			</div>
		</div>
	</div>
	<div class="col-md-12 product">
		<span class="product-title">BEP - General English Class</span>
		<div class="col-md-5 product-img" style="background-image: url('<?php echo e(asset('/img/bep.jpg')); ?>');">
		</div>
		<div class="col-md-7 product-desc">
			<p>General English Class dirancang khusus untuk jenjang sekolah menengah hingga dewasa. Tahapan belajar kalian dibagi menjadi 4 level yang membantu kalian mengembangkan kemampuan berbahasa Inggris dari dasar hingga maksimal. Kalian juga akan dibimbing dengan tutor yang tersertifikasi dan profesional di bidangnya. Pembelajaran di setiap sesinya juga dikemas dengan metode dan teknik yang komunikatif dan terfokus pada pengembangan kemampuan berbahasa.
		</p>
			<p><b>Lokasi: </b> Pontianak, Singkawang, Ketapang</p>
			<div class="col-md-12" style="padding:0;">
				<button class="product-btn" onclick="location.href='/products/language/english/bep'">Read More</button>
			</div>
		</div>
	</div>
  <div class="col-md-12 product">
    <span class="product-title">Young Learners</span>
    <div class="col-md-5 product-img" style="background-image: url('<?php echo e(asset('/img/young learner.jpg')); ?>');">
    </div>
    <div class="col-md-7 product-desc">
      <p>Young Learner Class adalah program untuk anak-anak dari kelas 1-6 SD. Sebagai siswa BP, anak anda akan mendapatkan 3 level kursus dengan kelas yang aktif dan interaktif dengan mengutamakan English Communicative Learning. Anak-anak akan belajar kemampuan bahasa Inggris secara mendasar untuk mengembangkan keterampilan sosial dan kognitif mereka.
    </p>
      <p><b>Lokasi: </b> Pontianak, Singkawang, Ketapang</p>
      <div class="col-md-12" style="padding:0;">
        <button class="product-btn" onclick="location.href='/products/language/english/bep'">Read More</button>
      </div>
    </div>
  </div>
	<div class="col-md-12 product">
		<span class="product-title">GMAT</span>
		<div class="col-md-5 product-img" style="background-image: url('<?php echo e(asset('/img/gmat.png')); ?>');">
		</div>
		<div class="col-md-7 product-desc">
			<p>Kelas persiapan GMAT Test di Best Partner memiliki program yang akan membantu kalian mendapatkan skor yang kalian inginkan. Kelas persiapan GMAT menyediakan paket yang fokus pada peningkatan keterampilan tes para siswa. Disini siswa akan diberikan contoh soal yang nyata dan latar belakang yang relevan mencakup analytical writing assessment, integrated reasoning, the quantitative section, dan verbal section. Program ini membantu siswa BP untuk mengasah keterampilan tes verbal maupun matematika dasar serta berlanjut dengan membantu kalian memahami soal-soal GMAT.
		</p>
			<p><b>Lokasi: </b> Pontianak, Singkawang, Ketapang</p>
			<div class="col-md-12" style="padding:0;">
				<button class="product-btn" onclick="location.href='/products/language/english/gmat'">Read More</button>
			</div>
		</div>
	</div>
	<div class="col-md-12 product">
		<span class="product-title">GRE</span>
		<div class="col-md-5 product-img" style="background-image: url('<?php echo e(asset('/img/gre.jpg')); ?>');">
		</div>
		<div class="col-md-7 product-desc">
			<p>GRE test atau Graduate Record Exam wajib diikuti oleh kandidat mahasiswa yang berencana mengikuti program S2 atau S3 di Amerika Serikat dan negara berbahasa Inggris lainnya. GRE digunakan untuk mengukur tingkat kemampuan siswa dalam memahami bacaan rumit dan menganalisa informasi kuantitatif. Ujian GRE akan menguji 3 hal yaitu Verbal Reasoning, Quantitative Reasoning dan Analytical Writing.
		</p>
			<p><b>Lokasi: </b> Pontianak, Singkawang, Ketapang</p>
			<div class="col-md-12" style="padding:0;">
				<button class="product-btn" onclick="location.href='/products/language/english/gre'">Read More</button>
			</div>
		</div>
	</div>
	<div class="col-md-12 product">
		<span class="product-title">SAT</span>
		<div class="col-md-5 product-img" style="background-image: url('<?php echo e(asset('/img/sat.jpg')); ?>');">
		</div>
		<div class="col-md-7 product-desc">
			<p>SAT merupakan ujian terstandarisasi dari kemampuan berpikir kritis untuk para calon mahasiswa di AS dan negara lain seperti Singapura. Kursus kami membantu siswa mengembangkan strategi ujian yang efektif secara interaktif, sehingga siswa akan senantiasa fokus dan termotivasi hingga waktu ujian tiba. Rencana pembelajaran dirancang secara khusus untuk memenuhi kebutuhan siswa sekolah menengah atas; menggunakan pendekatan inovatif sehingga mereka dapat memfokuskan waktu yang mereka miliki untuk memperoleh nilai terbaik. Sesi kelas yang menyenangkan akan meningkatkan kepercayaan diri dan keahlian berstrategi.
		</p>
			<p><b>Lokasi: </b> Pontianak, Singkawang, Ketapang</p>
			<div class="col-md-12" style="padding:0;">
				<button class="product-btn" onclick="location.href='/products/language/english/sat'">Read More</button>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_wo_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views//language/english.blade.php ENDPATH**/ ?>