
<div class="top-footer row">
	<div class="top-footer-left col-md-4">
		<img src="<?php echo e(asset('/img/logo_putih.png')); ?>" class="logo-footer">
		<p>  Didirikan pada tahun 2016, Best Partner Education adalah salah satu Konsultan Pendidikan Luar Negeri terbaik di Indonesia yang mewakili lebih dari 120 universitas dan perguruan tinggi di 12 negara. Dalam beberapa tahun terakhir, kami telah mengirim lebih dari 300 siswa ke berbagai lembaga di seluruh dunia.
		</p>	<nav class="col-md-12">
			<a href="../">Home</a> |
			<a href="/about_us">About</a> |
			<a href="/studying_abroad">Studying Abroad</a> |
			<a href="/products">Products & Services</a> |
			<a href="/news">Media</a> |
			<a href="/contact_us">Contact Us</a> |
		</nav>

		<div class="col-md-12 sosmed-wrapper">
			<h5><i class="fa fa-arrow-down" aria-hidden="true"></i> Click Me !</h5>
			<a class="logo-sosmed" href="https://wa.me/085821012006" target="_BLANK"> <i class="fa fa-whatsapp"></i></a>
			<a class="logo-sosmed" href="https://www.facebook.com/bestpartnereducation/" target="_BLANK"> <i class="fa fa-facebook "></i></a>
			<a class="logo-sosmed" href="https://www.instagram.com/bestpartnereducation/" target="_BLANK"> <i class="fa fa-instagram "></i></a>
			<a class="logo-sosmed" href="https://www.youtube.com/channel/UCicDSptmlROwc3B6kYEbUjw" target="_BLANK"> <i class="fa fa-youtube-play "></i></a>

		</div>
	</div>
	<div class="top-footer-right col-md-8">
		 <div class="col-md-4 centres-wrapper">

			 		 	<h5 class="col-md-12">Best Partner Pontianak</h5>
		 <!--	<div class="col-md-12 centres-item">

				<a style="color:white;text-decoration:underline" href="https://g.page/bestpartnereducation?share" target="_blank">
		 	<div class="centres-logo">
		 		<i class="fa fa-map-marker"></i>
		 	</div>
		 	<div class="centres-desc">
		 	Jl. Prof. Dr. Hamka No.29-30
		 		Pontianak, Kalimantan Barat
		 	</div></a>
		</div>-->


			<a style="color:white;text-decoration:underline" href="https://g.page/bestpartnereducation?share" target="_blank">
					<div class="col-md-12 centres-item" style="text-decoration:underline">
			<i class="fa fa-map-marker"></i>

		Jl. Prof. Dr. Hamka No.29-30
			Pontianak, Kalimantan Barat
		</div></a>
		 	<div class="col-md-12 centres-item">
		 		<i class="fa fa-phone"></i>
		 		(0561) 8172583
		 	</div>
		 	<div class="col-md-12 centres-item">
		 		<i class="fa fa-whatsapp"></i>
		 		<span class="wa-desc">
					+62 895-1513-9224<br>
					+62 858-2101-2006
		 		<span>
		 	</div>
		 	<div class="col-md-12 centres-item">
		 		<i class="fa fa-envelope"></i>
		 		info@bestpartnereducation.com
		 	</div>
		 </div>
		  <div class="col-md-4 centres-wrapper">
		 	<div class="col-md-12 centres-item">
		 	<h5 class="col-md-12">Best Partner <br> Singkawang</h5>

		 	<div class="centres-logo">
		 		<i class="fa fa-map-marker"></i>
		 	</div>
		 	<div class="centres-desc">
		 		Jl. S. M Tsjafioedin No. 58 D Lt. 2 No. 1 (Gedung NHP). Singkawang, Kalimantan Barat 79111
		 	</div>
		 	</div>
		 	<div class="col-md-12 centres-item">
		 	<div class="centres-logo">
		 		<i class="fa fa-whatsapp"></i>
		 	</div>
		 	<div class="centres-desc">
		 		+62 896-9333-9522
		 	</div>
		 	</div>
		 	<div class="col-md-12 centres-item">
		 	<div class="centres-logo">
		 		<i class="fa fa-envelope"></i>
		 	</div>
		 	<div class="centres-desc centres-email">
		 		counselor1-skw@bestpartnereducation.com
		 	</div>
		 	</div>
		 </div>
		  <div class="col-md-4 centres-wrapper">
		 	<div class="col-md-12 centres-item">
		 	<h5 class="col-md-12">Best Partner <br> Australia</h5>

		 	<div class="centres-logo">
		 		<i class="fa fa-map-marker"></i>
		 	</div>
		 	<div class="centres-desc">
		 		Level 33, Australia Square 264 George Street AU 2000
		 	</div>
		 	</div>

		 	<div class="col-md-12 centres-item">
		 	<div class="centres-logo">
		 		<i class="fa fa-whatsapp"></i>
		 	</div>
		 	<div class="centres-desc">
		 		+62 895-1513-9224
		 	</div>
		 	</div>
		 </div>

	</div>
</div>
<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/includes/top-footer.blade.php ENDPATH**/ ?>