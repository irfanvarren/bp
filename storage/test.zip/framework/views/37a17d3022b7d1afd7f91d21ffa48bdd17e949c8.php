<p>Nama : <?php echo e($email->nama); ?></p>
<p>Nama Program <?php echo e($email->nama_program); ?></p>
<p>Nama Tutor : <?php echo e($email->nama_tutor); ?></p>

<h3>Pertanyaan : </h3> 
<p>Tutor datang tepat waktu : <?php echo e($email->answer_1); ?></p>
<p>Menguasai Materi : <?php echo e($email->answer_2); ?></p>
<p>Menjelaskan materi dengan jelas : <?php echo e($email->answer_3); ?></p>
<p>Kesungguhan dalam menjadi siswa : <?php echo e($email->answer_4); ?></p>
<p>Sesi diskusi materi : <?php echo e($email->answer_5); ?></p>
<p>Memberikan komentar terhadap tugas dan ujian : <?php echo e($email->answer_6); ?></p>
<p>Terbuka terhadap opini siswa : <?php echo e($email->answer_7); ?></p>
<p>Peduli dengan pemahaman siswa : <?php echo e($email->answer_8); ?></p>
<p>Memperlakukan siswa dengan hormat : <?php echo e($email->answer_9); ?></p>
<p>Ketertarikan terhadap materi : <?php echo e($email->answer_10); ?></p>
<p>Membawa suasana kelas : <?php echo e($email->answer_11); ?></p>

<p>Kelebihan dan kekurangan tutor : <?php echo e($email->kelebihan_kekurangan); ?></p>
<p>Masukkan untuk meningkatkan kemampuan atau cara mengajar tutor : <?php echo e($email->masukkan); ?></p>
<p>Tanggapan anda mengenai lembaga ini : <?php echo e($email->tanggapan); ?></p>
<p>Rating Tutor : <?php echo e($email->rating); ?></p>
<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/email/tutorperformance.blade.php ENDPATH**/ ?>