<?php echo e($slot); ?>

<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>