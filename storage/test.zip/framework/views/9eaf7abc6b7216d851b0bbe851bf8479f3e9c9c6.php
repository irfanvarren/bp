  <!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('includes.news-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=5da17dc4bfe4730012572504&product=inline-share-buttons' async='async'></script>
        <!-- Fonts -->

        <!-- Styles -->
    </head>
    <body>
        <div class="container">
            <header class="row">
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <div id="main" class="row justify-content-center">
      <div class="news-article-wrapper">
        <div class="row">
          <?php echo $__env->yieldContent('content'); ?>
          <?php echo $__env->make('includes.news-sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>

    </div>

    <footer class="row">
      <div class="col-md-12">

          <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </footer>
  </div>

        <!-- </body></html> -->
    </body>
</html>
<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/layouts/bp_news.blade.php ENDPATH**/ ?>