<div class="row footer-bottom">
	<div class="col-md-12">
		<div class="row">


<div id="copyright text-right" class="col-md-5 copyright-left">Copyright © 2019 All rights reserved | Best Partner Education</div>
<div class="col-md-7 copyright-right">
	<nav class="copyright-nav">

			<a href="<?php echo e(url('copyrights')); ?>">Copyrights</a>
		<a href="<?php echo e(url('term_and_use')); ?>">Term & Use</a>
		<a href="<?php echo e(url('privacy_and_policy')); ?>">Privacy & policy</a>
		<a href="<?php echo e(url('disclaimer')); ?>">Disclaimer</a>
	</nav>

</div>
</div>
<div id="copyright text-right" class="col-md-6 copyright-left-mobile"><script language="JavaScript">
<!--
function y2k(number) { return (number < 1000) ? number + 1900 : number; }
var today = new Date();
var year = y2k(today.getYear());
document.write('© '+year+' Best Partner Education - All Rights Reserved');
//-->
</script>
</div>
</div>	</div>
<script type="text/javascript">
$('body').bind('copy paste',function(e) {
	e.preventDefault(); return false;
});
</script>
<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/includes/footer.blade.php ENDPATH**/ ?>