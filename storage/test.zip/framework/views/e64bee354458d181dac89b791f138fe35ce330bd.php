
<style media="screen">
  .banner-mobile{
    display:none;
    padding:0 !important;
  }
  .slick-slide,.home-title-wrapper{
height:inherit !important;
    }

  .home-content2 .news .news-border {
    padding: 0;
    box-shadow: 0px 2px 9px 2px rgba(0,0,0,.08);
  }
  .news{
    margin-bottom:30px;
  }
</style>
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
    <div class="home col-md-12">
      <div class="col-md-12 slick-slider3">
    <!--    <div class="slick-slide">
          <div class="col-md-12 banner-mobile" >
<img src="<?php echo e(asset('/img/banner/banner1-mobile.jpeg')); ?>" style="width:100%;" alt="">
          </div>
          <div class="banner">
<img src="<?php echo e(asset('/img/banner/banner1.jpeg')); ?>" style="width:100%;" alt="">
          </div>

        </div>-->

          <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="slick-slide">
          <?php if($data_banner->banner_type == "image"): ?>

          <div class="col-md-12 banner-mobile">
<img src="<?php echo e(asset($data_banner->mobile_image)); ?>" style="width:100%;" alt="">
          </div>
          <div class="banner">
<img src="<?php echo e(asset($data_banner->image)); ?>" style="width:100%;" alt="">
          </div>
        <?php else: ?>
          <div class="col-md-12 home-title-wrapper">

             <div class="home-title">
               <?php echo $data_banner->text; ?>

            <!-- <h1>Education Consultant</h1>
             <p class="col-md-12">
               Kami memberikan layanan jasa konsultasi studi luar negeri dengan biaya gratis dengan konsultan professional kami, ditambah lagi dengan pelatihan interview sampai anda lancar dan bisa.
               </p>
               <a  href="https://www.youtube.com/channel/UCicDSptmlROwc3B6kYEbUjw" target="_BLANK" class="home-btn home-btn1"> <i class=" fa fa-youtube-play" style="margin-right:15px;color:white;"></i> Watch Video </a>-->
             </div>
<div class="col-md-6 slider-img slider-img1" style="background-image:url('<?php echo e(asset($data_banner->image)); ?>');"> </div>
         </div>

       <?php endif; ?>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!--  <div class="slick-slide">
            <div class="col-md-12 home-title-wrapper">

               <div class="home-title">
               <h1>Education Consultant</h1>
               <p class="col-md-12">
                 Kami memberikan layanan jasa konsultasi studi luar negeri dengan biaya gratis dengan konsultan professional kami, ditambah lagi dengan pelatihan interview sampai anda lancar dan bisa.
                 </p>
                 <a  href="https://www.youtube.com/channel/UCicDSptmlROwc3B6kYEbUjw" target="_BLANK" class="home-btn home-btn1"> <i class=" fa fa-youtube-play" style="margin-right:15px;color:white;"></i> Watch Video </a>
               </div>
<div class="col-md-6 slider-img slider-img1" style="background-image:url('<?php echo e(asset('/img/Education Consultant.png')); ?>');"> </div>
           </div>
          </div>

          <div class="slick-slide">


            <div class="col-md-12 home-title-wrapper">

              <div class="home-title">
              <h1>IELTS Test Center</h1>
              <p class="col-md-12">
              Bekerja sama dengan IALF, kini IELTS official test sudah hadir di Pontianak. Best Partner Education merupakan satu-satunya Test Centre yang memiliki IELTS Test Room terstandarisasi dengan harga terjangkau.
                </p>
                <a  href="https://www.youtube.com/channel/UCicDSptmlROwc3B6kYEbUjw" target="_BLANK" class="home-btn home-btn2"> <i class=" fa fa-youtube-play" style="margin-right:15px;color:white;"></i> Watch Video </a>
              </div>
<div class="col-md-6 slider-img" style="background-image:url('<?php echo e(asset('/img/IELTS Test Center.png')); ?>');"> </div>

           </div>
          </div>
          <div class="slick-slide">


            <div class="col-md-12 home-title-wrapper">

              <div class="home-title">
              <h1>TOEFL Test Center</h1>
              <p class="col-md-12">
                TOEFL ITP juga merupakan kunci untuk meraih mimpimu. Kamu kini dapat mengikuti TOEFL ITP test dengan harga terjangkau, ruangan yang terstandarisasi, serta pelayanan yang informatif dan ramah di Best Partner Education.
                </p>
               <a  href="https://www.youtube.com/channel/UCicDSptmlROwc3B6kYEbUjw" target="_BLANK" class="home-btn home-btn3"> <i class=" fa fa-youtube-play" style="margin-right:15px;color:white;"></i> Watch Video </a>
              </div>
<div class="col-md-6 slider-img" style="background-image:url('<?php echo e(asset('/img/TOEFL Test Center.png')); ?>');"> </div>
           </div>
          </div>
          <div class="slick-slide">


            <div class="col-md-12 home-title-wrapper">

              <div class="home-title">
          		<h1>IELTS Preparation</h1>
          		<p class="col-md-12">
          			Program IELTS (Academic & General Training) dirancang untuk mempersiapkan kalian demi meraih tes skor yang kalian inginkan. Kalian juga akan dibimbing oleh tutor yang berpengalaman dan telah tersertifikasi (IELTS). Metode pengajaran yang digunakan ampuh untuk membantu kalian mencapai target nilai yang memuaskan.
          			</p>
          		<a  href="https://www.youtube.com/channel/UCicDSptmlROwc3B6kYEbUjw" target="_BLANK" class="home-btn home-btn4"> <i class=" fa fa-youtube-play" style="margin-right:15px;color:white;"></i> Watch Video </a>
          		</div>
              <div class="col-md-6 slider-img" style="background-image:url('<?php echo e(asset('/img/IELTS Preparation.png')); ?>');"> </div>

           </div>
         </div>
         <div class="slick-slide">


           <div class="col-md-12 home-title-wrapper">

             <div class="home-title">
         		<h1>Language Center</h1>
         		<p class="col-md-12">
         		Disini kamu bisa belajar bahasa (Inggris, Mandarin, Korea, Jepang, dan Jerman) mulai dari usia dan level berapa saja, karena Best Partner sangat mengerti kebutuhanmu. Mulai dari level young learner hingga upper intermediate. Untuk membantu perkembangan bahasamu, kamu akan dibibimbing oleh tutor yang terstandarisasi, bermotivasi tinggi, kelas yang nyaman serta metode belajar yang menyenangkan.
         			</p>
         			<a  href="https://www.youtube.com/channel/UCicDSptmlROwc3B6kYEbUjw" target="_BLANK" class="home-btn home-btn5"> <i class=" fa fa-youtube-play" style="margin-right:15px;color:white;"></i> Watch Video </a>
         		</div>
    <div class="col-md-6 slider-img" style="background-image:url('<?php echo e(asset('/img/English Center.png')); ?>');"> </div>
          </div>
        </div>-->
        </div>
    </div>
  <!--  	<div id="slider" class="col-md-12">
    <div class="col-md-12 content bg-slider active">

     <div class="col-md-6 home-title-wrapper">

    		<div class="home-title">
    		<h1>Education Consultant</h1>
    		<p class="col-md-12">
    			Kami memberikan layanan jasa konsultasi studi luar negeri dengan biaya gratis dengan konsultan professional kami, ditambah lagi dengan pelatihan interview sampai anda lancar dan bisa.
    			</p>
    			<button class="home-btn home-btn1"> <i class=" fa fa-youtube-play" style="margin-right:15px;"></i> Watch Video </button>
    		</div>

    </div>
    <div class="col-md-6 slider-img" style="background-image:url('/img/Education Consultant.png');background-position: right -43px bottom 0px"> </div>
    </div>
     <div class="col-md-12 content bg-slider active">

     <div class="col-md-6 home-title-wrapper">

    		<div class="home-title">
    		<h1>IELTS Test Center</h1>
    		<p class="col-md-12">
    		Bekerja sama dengan IALF, kini IELTS official test sudah hadir di Pontianak. Best Partner Education merupakan satu-satunya Test Centre yang memiliki IELTS Test Room terstandarisasi dengan harga terjangkau.
    			</p>
    			<button class="home-btn home-btn2"> <i class=" fa fa-youtube-play" style="margin-right:15px;"></i> Watch Video </button>
    		</div>

    </div>
    <div class="col-md-6 slider-img" style="background-image:url('/img/IELTS Test Center.png');"> </div>
    </div>
      <div class="col-md-12 content bg-slider active">

     <div class="col-md-6 home-title-wrapper">

    		<div class="home-title">
    		<h1>TOEFL Test Center</h1>
    		<p class="col-md-12">
    			TOEFL ITP juga merupakan kunci untuk meraih mimpimu. Kamu kini dapat mengikuti TOEFL ITP test dengan harga terjangkau, ruangan yang terstandarisasi, serta pelayanan yang informatif dan ramah di Best Partner Education.
    			</p>
    			<button class="home-btn home-btn3"> <i class=" fa fa-youtube-play" style="margin-right:15px;"></i> Watch Video </button>
    		</div>

    </div>
    <div class="col-md-6 slider-img" style="background-image:url('/img/TOEFL Test Center.png');"> </div>
    </div>
      <div class="col-md-12 content bg-slider active">

     <div class="col-md-6 home-title-wrapper">

    		<div class="home-title">
    		<h1>IELTS Preparation</h1>
    		<p class="col-md-12">
    			Program IELTS (Academic & General Training) dirancang untuk mempersiapkan kalian demi meraih tes skor yang kalian inginkan. Kalian juga akan dibimbing oleh tutor yang berpengalaman dan telah tersertifikasi (IELTS). Metode pengajaran yang digunakan ampuh untuk membantu kalian mencapai target nilai yang memuaskan.
    			</p>
    			<button class="home-btn home-btn4"> <i class=" fa fa-youtube-play" style="margin-right:15px;"></i> Watch Video </button>
    		</div>

    </div>
    <div class="col-md-6 slider-img" style="background-image:url('/img/IELTS Preparation.png');"> </div>
    </div>
      <div class="col-md-12 content bg-slider active">

     <div class="col-md-6 home-title-wrapper">

    		<div class="home-title">
    		<h1>Langguage Center</h1>
    		<p class="col-md-12">
    		Disini kamu bisa belajar bahasa (Inggris, Mandarin, Korea, Jepang, dan Jerman) mulai dari usia dan level berapa saja, karena Best Partner sangat mengerti kebutuhanmu. Mulai dari level young learner hingga upper intermediate. Untuk membantu perkembangan bahasamu, kamu akan dibibimbing oleh tutor yang terstandarisasi, bermotivasi tinggi, kelas yang nyaman serta metode belajar yang menyenangkan.
    			</p>
    			<button class="home-btn home-btn5"> <i class=" fa fa-youtube-play" style="margin-right:15px;"></i> Watch Video </button>
    		</div>

    </div>
    <div class="col-md-6 slider-img" style="background-image:url('/img/English Center.png');"> </div>
    </div>

<div class="col-md-12 content bg-slider">
       <div class="home-overlay home-overlay-b">

    		<div class="home-title">
    		<h1>IELTS Test Center</h1><button class="home-btn2" onclick="location.href='https://www.ielts.org/book-a-test/ielts/indonesia/best-partner-education'"> Register Now</button>
    		</div>
    	</div>
    </div>
     <div class="col-md-12 content bg-slider active">
     <div class="home-overlay home-overlay-b">

    		<div class="home-title">
    		<h1>TOEFL ITP Test Center</h1>
    		<button class="home-btn"> Read More </button>
    		</div>
    	</div>
    </div>
     <div class="col-md-12 content bg-slider active">
     <div class="home-overlay home-overlay-b">

    		<div class="home-title">
    		<h1>IELTS Preparation</h1>
    		<button class="home-btn"> Read More </button>
    		</div>
    	</div>
    </div>
    <div class="col-md-12 content bg-slider">
        <div class="home-overlay home-overlay-b">

    		<div class="home-title">
    		<h1>English Center</h1>
    		<button class="home-btn">See Our Courses</button>
    		</div>
    	</div>
    </div>
     <div class="col-md-12 content bg-slider active">
     <div class="home-overlay">

    	</div>
    </div>
</div>
	<div class="arrows-border">
    <div class="nav-arrows prev"></div>
    </div>
    <div class="arrows-border">
    <div class="nav-arrows next"></div>
	</div>
    </div>-->
<!--
 <div id="destination" class="col-md-12 destination-wrapper">
    	<div class="container">
    	<div class="row">
    	<h1>DESTINATION</h1>


<div class="col-md-12 slider-container">
<div class="slick-slider col-md-12 flags" style="text-align: center;width: 100%;">
  <div class="slick-slide"><img src="/img/australia.png" class="flag"><p>Australia</p></div>
  <div class="slick-slide"><img src="/img/new-zealand.png" class="flag"><p>New Zealand</p></div>
    <div class="slick-slide"><img src="/img/canada.png" class="flag"><p>Canada</p></div>
      <div class="slick-slide"><img src="/img/malaysia.png" class="flag"><p>Malaysia</p></div>
        <div class="slick-slide"><img src="/img/switzerland.png" class="flag"><p>Switzerland</p></div>
         <div class="slick-slide"><img src="/img/singapore.png" class="flag"><p>Singapore</p></div>
         <div class="slick-slide"><img src="/img/south-korea.png" class="flag"><p>South Korea</p></div>
     <div class="slick-slide"><img src="/img/negara/lama/australia.jpg" class="flag"><p>Australia</p></div>
  <div class="slick-slide"><img src="/img/new-zealand.png" class="flag"><p>New Zealand</p></div>
    <div class="slick-slide"><img src="/img/canada.png" class="flag"><p>Canada</p></div>
      <div class="slick-slide"><img src="/img/malaysia.png" class="flag"><p>Malaysia</p></div>
        <div class="slick-slide"><img src="/img/switzerland.png" class="flag"><p>Switzerland</p></div>
         <div class="slick-slide"><img src="/img/singapore.png" class="flag"><p>Singapore</p></div>
         <div class="slick-slide"><img src="/img/south-korea.png" class="flag"><p>South Korea</p></div>
</div>
</div>

    	</div>
    	</div>
    </div>-->
<div class="col-md-12 destination-wrapper">
    <h1>DESTINATION</h1>
    <div class="col-md-12 slick-slider1 country-wrapper" style="height:220px;">

        <div class="slick-slide" onclick="location.href='study-abroad/australia'">
            <div class="col-md-12 country" style="background-image:url('<?php echo e(asset('img/negara/lama/australia.jpg')); ?>')">
                <div class="country-overlay">
                    <h1>Australia</h1>
                </div>
            </div>
        </div>
          <div class="slick-slide" onclick="location.href='study-abroad/singapore'">
            <div class="col-md-12 country" style=" background-image:url('<?php echo e(asset('img/negara/lama/singapore.jpg')); ?>');">
                <div class="country-overlay"><h1>Singapore</h1></div>
            </div>
        </div>
          <div class="slick-slide" onclick="location.href='study-abroad/malaysia'">
            <div class="col-md-12 country"  style="background-image:url('<?php echo e(asset('img/negara/lama/malaysia.jpg')); ?>');">
                <div class="country-overlay"><h1>Malaysia</h1></div>
            </div>
        </div>
        <div class="slick-slide" onclick="location.href='study-abroad/new-zealand'">
            <div class="col-md-12 country" style="background-image:url('<?php echo e(asset('img/negara/lama/New Zealand.jpg')); ?>');">
                <div class="country-overlay"><h1>New Zealand</h1></div>
            </div>
        </div>
          <div class="slick-slide" onclick="location.href='study-abroad/switzerland'">
            <div class="col-md-12 country" style="background-image:url('<?php echo e(asset('img/negara/lama/Switzerland.jpg')); ?>');">
                <div class="country-overlay"><h1>Switzerland</h1></div>
            </div>
        </div>
          <div class="slick-slide" onclick="location.href='study-abroad/canada'">
            <div class="col-md-12 country" style="background-image:url('<?php echo e(asset('img/negara/lama/Canada.jpg')); ?>');">
                <div class="country-overlay"><h1>Canada</h1></div>
            </div>
        </div>

        <div class="slick-slide" onclick="location.href='study-abroad/south-korea'">
            <div class="col-md-12 country" style="background-image: url('<?php echo e(asset('img/negara/lama/South Korea.jpg')); ?>');">
                <div class="country-overlay"><h1>South Korea</h1></div>
            </div>
        </div>
          <div class="slick-slide" onclick="location.href='study-abroad/china'">
            <div class="col-md-12 country" style="background-image: url('<?php echo e(asset('img/negara/lama/China.jpg')); ?>');">
                <div class="country-overlay"><h1>China</h1></div>
            </div>
        </div>
          <div class="slick-slide" onclick="location.href='study-abroad/england'">
            <div class="col-md-12 country" style="background-image: url('<?php echo e(asset('img/negara/lama/England.jpeg')); ?>');">
                <div class="country-overlay"><h1>England</h1></div>
            </div>
        </div>
        <div class="slick-slide" onclick="location.href='study-abroad/france'">
            <div class="col-md-12 country" style="background-image: url('<?php echo e(asset('img/negara/lama/France.jpg')); ?>');">
                <div class="country-overlay"><h1>France</h1></div>
            </div>
        </div>
          <div class="slick-slide" onclick="location.href='study-abroad/ireland'">
            <div class="col-md-12 country" style="background-image: url('<?php echo e(asset('img/negara/lama/Ireland.jpg')); ?>');">
                <div class="country-overlay"><h1>Ireland</h1></div>
            </div>
        </div>
          <div class="slick-slide" onclick="location.href='study-abroad/netherland'">
            <div class="col-md-12 country" style="background-image: url('<?php echo e(asset('img/negara/lama/Netherland.jpg')); ?>');">
                <div class="country-overlay"><h1>Netherland</h1></div>
            </div>
        </div>
         <div class="slick-slide" onclick="location.href='study-abroad/spain'">
            <div class="col-md-12 country" style="background-image: url('<?php echo e(asset('img/negara/lama/Spain.jpg')); ?>');">
                <div class="country-overlay"><h1>Spain</h1></div>
            </div>
        </div>
         <div class="slick-slide" onclick="location.href='study-abroad/swedia'">
            <div class="col-md-12 country" style="background-image: url('<?php echo e(asset('img/negara/lama/Swedia.jpg')); ?>');">
                <div class="country-overlay"><h1>Swedia</h1></div>
            </div>
        </div>
         <div class="slick-slide" onclick="location.href='study-abroad/usa'">
            <div class="col-md-12 country" style="background-image: url('<?php echo e(asset('img/negara/lama/United States.jpg')); ?>');">
                <div class="country-overlay"><h1>United States</h1></div>
            </div>
        </div>
           <div class="slick-slide" onclick="location.href='study-abroad/indonesia'">
            <div class="col-md-12 country" style="background-image: url('<?php echo e(asset('img/negara/lama/Indonesia.jpg')); ?>');">
                <div class="country-overlay"><h1>Indonesia</h1></div>
            </div>
        </div>
    </div>
</div>

<div class="col-md-12 what_we_do">
	<h1>WHAT WE DO ?</h1>
	<div class="col-md-12 what_we_do-content-wrapper">
	   	<div class="col-md-4 what_we_do-content">
		<img class="lazy" data-src="<?php echo e(asset('/img/IMMIGRATIONN.png')); ?>">
		<div class="what_we_do-desc">
			<h3>Immigration</h3>
			<p>Kami memberikan layanan bantuan keimigrasian yang prima dan terpercaya</p>
		</div>

	</div>

	<div class="col-md-4 what_we_do-content">
		<img class="lazy" data-src="<?php echo e(asset('/img/TESTING AND TRAINING.png')); ?>">
	<div class="what_we_do-desc">
			<h3>IELTS Preparation & Test</h3>
			<p>Dapatkan nilai IELTS yang anda inginkan dengan kelas IELTS Training kami. Kami juga melaksanakan Test IELTS Resmi Setiap bulannya</p>
		</div>
	</div>
	<div class="col-md-4 what_we_do-content">
		<img class="lazy" data-src="<?php echo e(asset('/img/CONSULTATIONN.png')); ?>">
		<div class="what_we_do-desc">
			<h3>Consultation</h3>
			<p>Ingin belajar atau bekerja keluar negeri? Kami siap membantu</p>
		</div>
	</div>
	 </div>
	 <div class="col-md-12 what_we_do-content-wrapper" style="padding-top:0;">
	   	<div class="col-md-4 what_we_do-content">
		<img class="lazy" data-src="<?php echo e(asset('/img/toefl preparation.png')); ?>" alt="toefl preparation & test">
		<div class="what_we_do-desc">
			<h3>TOEFL Preparation & Test </h3>
			<p>Kelas Persiapan TOEFL dan Tes TOEFL resmi</p>
		</div>

	</div>

	<div class="col-md-4 what_we_do-content">
		<img class="lazy" data-src="<?php echo e(asset('/img/accomodation.png')); ?>" alt="accommodation & transportation">
	<div class="what_we_do-desc">
			<h3>Accommodation & Transportation</h3>
			<p>Kami membantu mencarikan tempat tinggal dan transportasi</p>
		</div>
	</div>
	<div class="col-md-4 what_we_do-content">
		<img class="lazy" data-src="<?php echo e(asset('/img/study tour.png')); ?>" alt="study tour">
		<div class="what_we_do-desc">
			<h3>Study Tour</h3>
			<p>Membantu tur belajar</p>
		</div>
	</div>

	 </div>
</div>
 <div class="col-md-12 home-content2">

      <div class="col-md-12">
        <h3>NEWS</h3>
        <hr>
      </div>
    	<div class="col-md-12 news-wrapper">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		<a style="color:black" target="_blank" class="news-link" href="<?php echo e(url("media/news/".date("Y/m",strtotime($data_news->created_at)).'/'.$data_news->slug)); ?>">

        			<div class="col-md-4 news">
        				<div class="col-md-12 news-border">
        					<div class="col-md-12 news-bg-img" style="background-image:url(' <?php echo e(Storage::disk('news')->url($data_news->image)); ?>');">
        					</div>
        					<div class="col-md-12 news-bottom">
        						<div class="col-md-12 news-info">
        							<ul>
        								<li><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;<?php echo e(date("l, d M Y",strtotime($data_news->created_at))); ?></li>
        							</ul>
        						</div>
        						<h5 class="col-md-12 news-title"> <div class="row">
        							<span style="line-height:1.7rem;max-height:3.4rem"><?php echo e(ucwords($data_news->title)); ?></span>
        						</div> </h5>
        						<div class="col-md-12 news-desc">
        						  <p><?php echo str_limit(strip_tags($data_news->body),252,$end = "..."); ?></p>
        						</div>
        					</div>
        				</div>
        			</div>
        		</a>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</div>
      <div class="col-md-12">
        <a href="media/news" type="button" class="btn btn-primary" style="width:180px;margin: 0 auto;border: none;padding:8px;display:block;" name="button">Read More</a>
      </div>
    </div>
    <!--
     <div class="col-md-12 home-content1">
    	    	<div class="col-md-6 about_img" style="background-image:url('/img/about_bp.jpg');">

    	</div>
    	<div class="col-md-6 about-desc">
    		<h1>ABOUT US</h1>
    		<p>Best Partner merupakan perusahaan yang bergerak dan berfokus dalam bidang pendidikan. Kami memberikan pelayanan terbaik dan terlengkap untuk anda yang ingin mendapatkan pendidikan yang lebih baik. Pelayanan kami yang sangat lengkap yaitu melayani tes & persiapan IELTS, pelatihan bahasa inggris dengan tenaga pengajar yang profesional, ramah dan berpengalaman, melayani persiapan dan pengurusan kuliah ke luar negeri. Kami menyediakan berbagai macam solusi untuk setiap masalah yang dihadapi oleh siswa sebelum melanjutkan pendidikannya ke luar negeri</p>
    		<button class="readmore-btn" onclick="location.href='/about_us'">Read More</button>
    	</div>
    </div>
-->


    <div class="col-md-12 testimony-wrapper">

    	<div class="col-md-12 testimony-overlay"></div>
    	<div class="col-md-12 testimony-content">

    		<div class="col-md-12">
    			<h2 class="col-md-12">TESTIMONIES</h2>
      <?php $__currentLoopData = $testimony; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_testimony): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-12 testimony">
    				<!--<div class="col-md-4">
    					<img class="testimony-photo" src="/img/ivan very.png">-->

                        <img class="testimony-photo lazy" data-src="<?php echo e(Storage::disk('public')->url($data_testimony->image)); ?>">
    			<h4 class="testimony-name"><?php echo e($data_testimony->name); ?></h4>
    			<p><?php echo e($data_testimony->testimony); ?></p>

    			</div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		</div>
        <div class="col-md-12">
          <div class="myslider-dots" style="height:5%;text-align:center;">
            <?php $no_testimony = 0 ?>
            <?php $__currentLoopData = $testimony; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_testimony): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <span class="dot" onclick="currentSlide(<?php echo e($no_testimony); ?>)" style="border:none;"></span>
            <?php $no_testimony++ ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!--<span class="dot" onclick="currentSlide(1)"></span>
        <span class="dot" onclick="currentSlide(2)"></span>
        <span class="dot" onclick="currentSlide(3)"></span>
        <span class="dot" onclick="currentSlide(4)"></span>
          <span class="dot" onclick="currentSlide(5)"></span>-->
        </div>
        </div>

    	</div>

    </div>
    <div class="col-md-12 institution-logo">
	<div class="col-md-12 slider-container">
<div class="slick-slider2 col-md-12 flags" style="text-align: center;width: 100%;">
  <!--<div class="slick-slide"><img src="/img/ialf.gif" class="testimony-logo"></div>-->
  <div class="slick-slide"><img data-src="<?php echo e(asset('/img/ielts.png')); ?>" class="lazy partnership-logo"></div>
</div>
	</div>
</div>

<script type="text/javascript">
$(document).ready(function(){
$('.slick-slider3').slick({
  infinite: true,
slidesToScroll: 1,
slidesToShow:1,
lazyLoad: 'ondemand',
rows:1,
   prevArrow: '<a class="myslick-prev myslick-nav myslick-nav2" ><i class="fa fa-angle-left"></i></a>',
            nextArrow: '<a class="myslick-next myslick-nav myslick-nav2"> <i class="fa fa-angle-right"></i> </a>',
autoplay:true,
autoplaySpeed:4500,

  responsive: [
  {
    breakpoint: 600,
    settings: {
      arrows:false,
        adaptiveHeight: true,
    }
  }
]
});
  $('.slick-slider1').slick({
    infinite: true,
  slidesToScroll: 2,
  slidesToShow:3,
  rows:1,
  autoplay:true,
  autoplaySpeed:2500,
  responsive: [
    {
        breakpoint:1200,
        settings:{
            slidesToShow:3,
            slidesToScroll:3,
        }
    },
    {
      breakpoint: 1000,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        infinite: true,
      }
    },
    {
      breakpoint: 745,
      settings: {
        slidesToShow: 1,
        slidesToScroll:1
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows:false,
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
  });
  $('.slick-slider2').slick({
    infinite: true,
  slidesToScroll: 1,
  slidesToShow:1,
  autoplay:true,
  rows: 2,
  autoplaySpeed:2500,
  arrows:false,
  responsive: [

    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows:false,
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
  });
    $(".bg-slider").hide();    $(".bg-slider:first-child").show();
    $(".prev").click(function(){
        slidePrev();
    })

    $(".next").click(function(){
        slideNext();
    })

    $(".nav-dots div").click(function(){
        slideTo($(this).index());
    })
});
function myFunction(x) {
x.classList.toggle("change");
}
function slidePrev() {
    if ($("#slider .active").index() == 0) {
        slideTo($("#slider .bg-slider").length - 1);
    }
    else {
        slideTo($("#slider .active").index() - 1);
    }
}

function slideNext() {
    if ($("#slider .active").index() == $("#slider .bg-slider").length - 1) {
        slideTo(0);
    }
    else {
        slideTo($("#slider .active").index() + 1);
    }
}

function slideTo(slide) {
    $("#slider .active").fadeOut().removeClass("active");
    $("#slider .bg-slider").eq(slide).fadeIn().addClass("active");

    $(".nav-dots .current").removeClass("current");
    $(".nav-dots div").eq(slide).addClass("current");
}
$(window).scroll(function (event) {
    var scroll = $(window).scrollTop();
    // Do somethin
    if (scroll >= 400){
  /*  $('header').css({'position': 'fixed', 'top': '0', 'left': '15px','background' : '#2E62A6','padding':'15px'});
      $('.nav>li>a').css({'color' : 'white','font-weight':'bold'});
      $('.nav>li>a.active').css({'border-bottom':'3px solid white'});
      $('.logo').attr('src','/img/logo_putih.png');
      $('.logo').css({'width':'150px'});
      $('.nav-wrapper').css({'padding':'0 15px'});
*/

    }else if(scroll < 400){
  /*    $('header').css({'position': 'relative','background' : '#F8FAFE','padding':'24px 10px'});
      $('.nav>li>a').css({'color' : '#333'});
      $('.nav>li>a.active').css({'border-bottom':'3px solid #3a6ca5','color':'#3a6ca5'});
      $('.logo').attr('src','/img/logo.png');
      $('.logo').css({'width':'200px'});*/
    }
});

</script>
<script>
var slideIndex = 0;
var timer;
showSlides();

function currentSlide(n) {
  clearTimeout(timer);
  showSlides(slideIndex = n);

}

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("testimony");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
   // Change image every 2 seconds
   timer = setTimeout(showSlides, 10000);
}
			(function() {
				function logElementEvent(eventName, element) {
					console.log(
						Date.now(),
						eventName,
						element.getAttribute("data-src")
					);
				}
				var callback_enter = function(element) {
					logElementEvent("🔑 ENTERED", element);
				};
				var callback_exit = function(element) {
					logElementEvent("🚪 EXITED", element);
				};
				var callback_reveal = function(element) {
					logElementEvent("👁️ REVEALED", element);
				};
				var callback_loaded = function(element) {
					logElementEvent("👍 LOADED", element);
				};
				var callback_error = function(element) {
					logElementEvent("💀 ERROR", element);
					element.src =
						"https://via.placeholder.com/440x560/?text=Error+Placeholder";
				};
				var callback_finish = function() {
					logElementEvent("✔️ FINISHED", document.documentElement);
				};
				var ll = new LazyLoad({
					elements_selector: ".lazy",
					// Assign the callbacks defined above
					callback_enter: callback_enter,
					callback_exit: callback_exit,
					callback_reveal: callback_reveal,
					callback_loaded: callback_loaded,
					callback_error: callback_error,
					callback_finish: callback_finish
				});
			})();
		</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/home.blade.php ENDPATH**/ ?>