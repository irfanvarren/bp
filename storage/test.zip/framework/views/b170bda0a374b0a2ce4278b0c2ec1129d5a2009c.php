
<?php $__env->startSection('title', 'IELTS Class'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12 content-header" style="/*background-image: linear-gradient(to bottom right, #244272,#99c0ff);*/background-image:url('<?php echo e(asset('/img/ielts.jpg')); ?>');">
	<div style="background-image: linear-gradient(to bottom right, #1c4e9e,#74bff2);width: 100%;height: 100%;position: absolute;top:0;left: 0;z-index: 1;opacity: 0.7;"></div>
		<div class="content-title" >
	<p><h1>IELTS Class</h1></p>
	<p>IELTS Class Preparation</p>
	<a href="https://wa.me/6283151281946" target="_blank" class="content-btn"> Daftarkan Sekarang</a>
	</div>
</div>
<div class="col-md-12 content-wrapper class-content-wrapper">
	<div class="col-md-12 content-nav">
		<nav>
			<a onclick="scroll_to('deskripsi')">
				Deskripsi
			</a>
			<a onclick="scroll_to('learn-exp')">
				Pengalaman Belajar
			</a>
			<a onclick="scroll_to('target')">
				Target Belajar
			</a>
		</nav>
	</div>
	<div class="col-md-12 class-content" id="deskripsi">
		<div class="col-md-8" style="padding:0;">
		<h2>About This Program</h2>
		<p>Program IELTS (Academic & General Training) dirancang untuk mempersiapkan kalian untuk meraih tes skor yang kalian inginkan. <br> <br> Kalian juga akan dibimbing oleh tutor yang berpengalaman dengan tes IELTS dan telah tersertifikasi (IELTS) dengan nilai minimal 7 (good language user). <br> <br> Metode pengajaran yang digunakan ampuh untuk membantu kalian mencapai target nilai yang memuaskan.</p>
		<b><h2>Kelas & Jadwal Belajar</h2></b>
	<p>
		Terdapat 3 jenis kelas: Regular (30 Jam), Intensive 1 (50 Jam), Intensive 2 (60 Jam)<br><br>
Selamat kegiatan intensif, siswa belajar dari senin-jum’at dalam seminggu dengan jam pelajaran yang akan ditentukan oleh Best Partner Education yang tentu tidak akan mengganggu aktifitas siswa

	</p>
		</div>
		<div class="col-md-4 class-sidebar">
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/ielts/33.png')); ?>">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>Pembelajaran Yang Intensif</h3>
					<p>Disetiap sesi, kalian akan diberikan pembelajaran yang intensif dan feedback secara rinci untuk meningkatkan efektivitas proses belajar.</p>
				</div>
			</div>
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/ielts/22.png')); ?>">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>Metode Pengajaran Yang Efektif</h3>
					<p>Tutor menggunakan metode pengajaran yang efektif seperti Task Based Learning dan Focus Skill Development yang mendukung pengembangan kemampuan berbahasa Inggris secara maksimal.</p>
				</div>
			</div>
			<div class="class-sidebar-content col-md-12">
				<div class="col-md-3 class-sidebar-img">
					<img src="<?php echo e(asset('/img/ielts/11.png')); ?>">
				</div>
				<div class="col-md-9 class-sidebar-desc">
					<h3>Supplementary Exercise</h3>
					<p>Tutor juga menyediakan supplementary exercise sebagai sarana latihan intensif di luar sesi program.</p>
				</div>
			</div>

		</div>
	</div>

	<div class="col-md-12 target-wrapper" id="target" style="border-top:1px solid #ccc">
		<h1> Target Pembelajaran</h1>
		<div class="col-md-3 target tablink" onclick="openTabs(event,'listening')">
			<div class="target-header"><img src="<?php echo e(asset('/img/listening2.png')); ?>">
			<p>Listening</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12"> Dapat memahami ide utama dari sebuah pembicaraan baik monolog maupun dialog dengan topik yang beragam.</div>
				<div class="col-md-12"> Dapat memahami informasi factual yang spesifik yang ada pada sebuah dialog ataupun monolog.</div>
				<div class="col-md-12"> Dapat mengenal tipe soal yang diujikan di tes resmi dan memahami cara pengerjaan tiap tipe soal.</div>
			</div>
		</div>
		<div class="col-md-3 target tablink" onclick="openTabs(event,'reading')">
			<div class="target-header">
			<img src="<?php echo e(asset('/img/reading2.png')); ?>">
			<p>Reading</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12">Dapat secara cepat dan tepat mencari jawaban untuk setiap jenis pertanyaan di tiap section. </div>
				<div class="col-md-12">Dapat memahami kosakata berlevel akademik untuk mempermudah kalian menjawab soal pada reading section.</div>
				<div class="col-md-12">Membiasakan siswa untuk membaca dan memahami instruksi soal reading section dengan benar dan tepat.</div>
			</div>
		</div>
		<div class="col-md-3 target tablink" onclick="openTabs(event,'writing')">
			<div class="target-header">
			<img src="<?php echo e(asset('/img/writing2.png')); ?>">
			<p>Writing</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12">Mengetahui standar penulisan yang digunakan pada Writing Task 1 dan Writing Task 2.</div>
				<div class="col-md-12">Mengetahui strategi pengerjaan dan standar penilaian writing test pada IELTS Official Test.</div>
				<div class="col-md-12">Mendapatkan kosakata yang relevan yang mendukung untuk hasil tulisan yang baik. </div>
				<div class="col-md-12">Mendapatkan contoh penulisan yang baik beserta dengan criteria dan penjelasan masing-masing contoh secara rinci.</div>
			</div>
		</div>
		<div class="col-md-3 target tablink" onclick="openTabs(event,'speaking')">
			<div class="target-header">
			<img src="<?php echo e(asset('/img/speaking2.png')); ?>">
			<p>Speaking</p>
			</div>
			<div class="col-md-12 target-content">
				<div class="col-md-12">Memahami sistem penilaian pada semua speaking task yang diujikan.</div>
				<div class="col-md-12">Mendapatkan tips dan trick untuk menjawab pertanyaan dan menyelesaikan tiap task yang diujikan.</div>
				<div class="col-md-12">Mendapatkan kosakata yang relevan dalam menjawab tiap pertanyaan yang diujikan.</div>
			</div>
		</div>
	</div>
		<div class="col-md-12 learn-exp" id="learn-exp">
		<h1>Pengalaman Belajar</h1>
		<div class="learn-vid-wrapper col-md-12">
			<div class="col-md-4">
				<div class="col-md-12 learn-vid">
					<section class="videos-section">
		  <div class="col-cont">
		    <div class="youtube-container home-youtube-container embed-responsive-item" id="videoPlayer">
		      <div class="homeVideoThumbnail home-videoplayer" id="vid-o5sHCTRKK2g"><img style="width:100%" src="//img.youtube.com/vi/o5sHCTRKK2g/0.jpg" />    <i class="fa fa-youtube-play homeVideoPlayButton"></i></div>

		    </div>

		  </div>
		</section>
		 <div class="video-desc" style="padding-top:5px;">IELTS Official test testimoni~Yanti "Jangan Anggap IELTS mudah"</div>
				</div	>

			</div>
			<div class="col-md-4">
				<div class="col-md-12 learn-vid">
					<section class="videos-section">
		  <div class="col-cont">
		    <div class="youtube-container home-youtube-container embed-responsive-item" id="videoPlayer">
		      <div class="homeVideoThumbnail home-videoplayer" id="VzGKY8lv7Dw"><img style="width:100%;" src="//img.youtube.com/vi/VzGKY8lv7Dw/0.jpg" />    <i class="fa fa-youtube-play homeVideoPlayButton"></i></div>

		    </div>

		  </div>
		</section>
		 <div class="video-desc" style="padding-top:5px;">Testimonial IELTS Preparation 30 hours and got 7.0 bandscore</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="col-md-12 learn-vid">
					<section class="videos-section">
			<div class="col-cont">
				<div class="youtube-container home-youtube-container embed-responsive-item" id="videoPlayer">
					<div class="homeVideoThumbnail home-videoplayer" id="vid-223LvPKG_N0"><img style="width:100%;" src="//img.youtube.com/vi/223LvPKG_N0/0.jpg" />    <i class="fa fa-youtube-play homeVideoPlayButton"></i></div>

				</div>

			</div>
		</section>
		 <div class="video-desc" style="padding-top:5px;">Vianey priscilla " IELTS preparation class" 6.0 bandscores</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
$(document).ready(function(e) {
  $('.homeVideoThumbnail').click(function(test){
    var id = $(this).attr('id').replace('vid-', '');
    var title = $(this).children("span").html();
    var descrip = $(this).children("em").html();
    var vid = '<iframe src="//www.youtube.com/embed/' + id + '?autoplay=1" width="100%" height="200" frameborder="0" allowfullscreen></iframe>';
    if (typeof title != 'undefined') {
        var vid = vid + '<p>' + title + ' &mdash; <em>' + descrip + '</p>';
    }
    //$('#videoPlayer',this).html(vid);
$(this).parent().html(vid);
  });
//  $('.homeVideoPlayButton').click(function(){
//      $('.homeVideoThumbnail').click();
//  });
});

/*
var video_wrapper = $('.youtube-video-place');
//  Check to see if youtube wrapper exists
if(video_wrapper.length){
// If user clicks on the video wrapper load the video.
$('.play-youtube-video').on('click', function(){
	alert('test');
/* Dynamically inject the iframe on demand of the user.
 Pull the youtube url from the data attribute on the wrapper element.
video_wrapper.html('<iframe allowfullscreen frameborder="0" class="embed-responsive-item" src="' + video_wrapper.data('yt-url') + '"></iframe>');
});
}
*/
function scroll_to(div){
	 $('html, body').animate({
        scrollTop: $("#"+div).offset().top - 230
    }, 1000);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_wo_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views//language/english/ielts-class.blade.php ENDPATH**/ ?>