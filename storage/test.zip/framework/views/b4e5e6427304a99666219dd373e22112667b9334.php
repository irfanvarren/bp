<footer class="footer">
</footer>
<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/layouts/footers/auth.blade.php ENDPATH**/ ?>