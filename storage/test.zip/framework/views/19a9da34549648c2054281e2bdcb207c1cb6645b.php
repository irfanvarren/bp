
<?php $__env->startSection('title', 'Media'); ?>
<?php $__env->startSection('content'); ?>
<!--<div class="content-header col-md-12" style="background-image:url('/img/about.jpg');">
	<h1>About Us</h1>
</div>-->
<div class="col-md-12 media content-header" style="height:500px;">
  <div class="col-md-12 slick-slider" style="padding:0;height:90%;">
    <div class="slick-slide">
      <div class="col-md-12 recent-events-img" style="background-image:url('<?php echo e(asset('/img/events/events1.jpg')); ?>')">
        <div class="center">
          <h1>Seminar IKIP PGRI Pontianak</h1>
          <h5>8 May 2018</h5>
        </div>
      </div>
    </div>
  <!--  <div class="slick-slide">
      <div class="col-md-12 recent-events-img" style="background-image:url('<?php echo e(asset('/img/events/events1.jpg')); ?>')">
        <div class="center">
          <h1>Seminar IKIP PGRI Pontianak</h1>
          <h5>8 May 2018</h5>
        </div>
      </div>
    </div>
    <div class="slick-slide">
      <div class="col-md-12 recent-events-img" style="background-image:url('<?php echo e(asset('/img/events/events1.jpg')); ?>')">
        <div class="center">
          <h1>Seminar IKIP PGRI Pontianak</h1>
          <h5>8 May 2018</h5>
        </div>
      </div>
    </div>-->
  </div>

</div>
<!--<div class="events-wrapper col-md-12" style="padding:60px;">
  <a style="color:black" target="_blank" href='https://pontianak.tribunnews.com/2019/03/29/meraih-score-ielts-terbaik-bersama-best-partner-education-pontianak'>



    <div class="col-md-4 news">
      <div class="col-md-12 news-border">
        <div class="col-md-12 news-bg-img" style="background-image:url(<?php echo e(asset('/img/news/foto-bersama-saat-kegiatan-ielts-test-official-23-maret-2019.jpg')); ?>);">
        </div>
        <div class="col-md-12 news-bottom">
          <div class="col-md-12 news-info">
            <ul>
              <li><i class="fa fa-calendar" aria-hidden="true"></i> 20 May 2019</li>
            </ul>
          </div>
          <h4>Meraih Score IELTS Terbaik Bersama Best Partner Education Pontianak</h4>
          <p class="col-md-12 news-desc">
            Best Partner Education adakan Workshop dan sharing untuk memberikan informasi kepada peserta yang ingin berkuliah ke Korea, tepatnya di Solbridge International School Of Business yang di ikuti oleh 100 peserta di Hotel Harris, rabu
            (3/4/2019).
          </p>
        </div>
      </div>
    </div>
  </a>

  <a style="color:black" target="_blank" href='https://pontianak.tribunnews.com/2019/03/29/meraih-score-ielts-terbaik-bersama-best-partner-education-pontianak'>



    <div class="col-md-4 news">
      <div class="col-md-12 news-border">
        <div class="col-md-12 news-bg-img" style="background-image:url(<?php echo e(asset('/img/news/foto-bersama-saat-kegiatan-ielts-test-official-23-maret-2019.jpg')); ?>);">
        </div>
        <div class="col-md-12 news-bottom">
          <div class="col-md-12 news-info">
            <ul>
              <li><i class="fa fa-calendar" aria-hidden="true"></i> 20 May 2019</li>
            </ul>
          </div>
          <h4>Meraih Score IELTS Terbaik Bersama Best Partner Education Pontianak</h4>
          <p class="col-md-12 news-desc">
            Best Partner Education adakan Workshop dan sharing untuk memberikan informasi kepada peserta yang ingin berkuliah ke Korea, tepatnya di Solbridge International School Of Business yang di ikuti oleh 100 peserta di Hotel Harris, rabu
            (3/4/2019).
          </p>
        </div>
      </div>
    </div>
  </a>

  <a style="color:black" target="_blank" href='https://pontianak.tribunnews.com/2019/03/29/meraih-score-ielts-terbaik-bersama-best-partner-education-pontianak'>



    <div class="col-md-4 news">
      <div class="col-md-12 news-border">
        <div class="col-md-12 news-bg-img" style="background-image:url(<?php echo e(asset('/img/news/foto-bersama-saat-kegiatan-ielts-test-official-23-maret-2019.jpg')); ?>);">
        </div>
        <div class="col-md-12 news-bottom">
          <div class="col-md-12 news-info">
            <ul>
              <li><i class="fa fa-calendar" aria-hidden="true"></i> 20 May 2019</li>
            </ul>
          </div>
          <h4>Meraih Score IELTS Terbaik Bersama Best Partner Education Pontianak</h4>
          <p class="col-md-12 news-desc">
            Best Partner Education adakan Workshop dan sharing untuk memberikan informasi kepada peserta yang ingin berkuliah ke Korea, tepatnya di Solbridge International School Of Business yang di ikuti oleh 100 peserta di Hotel Harris, rabu
            (3/4/2019).
          </p>
        </div>
      </div>
    </div>
  </a>
</div>-->
<script type="text/javascript">
  $(document).ready(function() {
    $('.slick-slider').slick({
      infinite: true,
      dots: true,
      slidesToScroll: 1,
      slidesToShow: 1,
      rows: 1,
      prevArrow: '<a class="myslick-prev myslick-nav"><i class="fa fa-angle-left"></i></a>',
      nextArrow: '<a class="myslick-next myslick-nav"> <i class="fa fa-angle-right"></i> </a>',
      customPaging: function(slider, i) {
        return '<i class="fa fa-circle" id=' + i + '></i>';
      },
      autoplay: true,
      autoplaySpeed: 2500,

      responsive: [{
        breakpoint: 600,
        settings: {
          adaptiveHeight: true,
        }
      }]
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bp_wo_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/events.blade.php ENDPATH**/ ?>