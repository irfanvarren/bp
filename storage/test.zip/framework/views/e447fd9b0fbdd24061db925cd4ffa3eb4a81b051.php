<div class="col-md-4 sidebar">
  <div class="row">

<div class="col-md-12">
  <h3>Newest News</h3>
	<hr class="news-line" style="width:inherit;">
</div>
  <?php $__currentLoopData = $new_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_new_news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="class-sidebar-content col-md-12">
              <a href="<?php echo e(url("media/news/".$data_new_news->created_at->format("Y/m/").$data_new_news->slug)); ?>">
          <div class="row">


              <div class="col-md-8 class-sidebar-desc">
        <?php echo e(ucwords(str_limit($data_new_news->title,42))); ?>


                </div>
                <div class="col-md-4 class-sidebar-img">
                    <img src="<?php echo e(Storage::disk('news')->url($data_new_news->image)); ?>">
                </div>
            </div>
                    </a>
                </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

          </div>
<!--<?php
$i = 1;
$max_news = 2;
?>
<div class="sidebar col-md-3">
	<h3>Recent News & Events</h3>
<?php for($i; $i <= $max_news; $i++): ?>
    <?php if($i <= $max_news): ?>

	<div class="col-md-12 news">
    				<div class="col-md-4 news-img">
    					<img src="/img/news1.jpg">
    				</div>
    				<div class="col-md-8">
    					<div class="col-md-12 news-info">
    				<ul>
    					<li><i class="fa fa-calendar" aria-hidden="true"></i> 20 May 2019</li>
    				</ul>
    			</div>
    			<h3>Events <?php echo e($i); ?></h3>
    			<p class="col-md-12 news-desc">
    				Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
    			</p>
    				</div>
    			</div>

   		<?php endif; ?>
    <?php if($i >$max_news): ?>

    <?php break; ?>
    <?php endif; ?>
<?php endfor; ?>
</div>
	<div class="col-md-5 news newest-news">
    			<img src="/img/news1.jpg">
    			<div class="col-md-12 news-info">
    				<ul>
    					<li><i class="fa fa-calendar" aria-hidden="true"></i> 20 May 2019</li>
    				</ul>
    			</div>
    			<h3>Events 1</h3>
    			<p class="col-md-12 news-desc">
    				Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
    			</p>
    		</div>
    		<div class="col-md-7 news-right">
    			<div class="col-md-12 news">
    				<div class="col-md-4 news-img">
    					<img src="/img/news1.jpg">
    				</div>
    				<div class="col-md-8">
    					<div class="col-md-12 news-info">
    				<ul>
    					<li><i class="fa fa-calendar" aria-hidden="true"></i> 20 May 2019</li>
    				</ul>
    			</div>
    			<h3>Events 1</h3>
    			<p class="col-md-12 news-desc">
    				Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
    			</p>
    				</div>
    			</div>

    			<div class="col-md-12 news">
    				<div class="col-md-4 news-img">
    					<img src="/img/news1.jpg">
    				</div>
    				<div class="col-md-8">
    					<div class="col-md-12 news-info">
    				<ul>
    					<li><i class="fa fa-calendar" aria-hidden="true"></i> 20 May 2019</li>
    				</ul>
    			</div>
    			<h3>Events 1</h3>
    			<p class="col-md-12 news-desc">
    				Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
    			</p>
    				</div>
    			</div>

    			<div class="col-md-12 news">
    				<div class="col-md-4 news-img">
    					<img src="/img/news1.jpg">
    				</div>
    				<div class="col-md-8">
    					<div class="col-md-12 news-info">
    				<ul>
    					<li><i class="fa fa-calendar" aria-hidden="true"></i> 20 May 2019</li>
    				</ul>
    			</div>
    			<h3>Events 1</h3>
    			<p class="col-md-12 news-desc">
    				Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
    			</p>
    				</div>
    			</div>
    		</div>-->
<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/includes/news-sidenav.blade.php ENDPATH**/ ?>