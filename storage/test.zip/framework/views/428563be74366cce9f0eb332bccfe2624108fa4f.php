<head>
  <style media="screen">
  .wrapper{
        margin:100px auto;
        width:500px;

          display:block;
  }
  table{
    border-collapse: collapse;
    width:100%;

  }
  table tr, table td, table th{
    padding:8px;
    text-align:left;
    border:1px solid black
  }
    </style>
</head>
<h2>Data Pendaftaran Les Bahasa Inggris</h2>
<?php
$nama = '';
if($email->nama_depan!=''){
$nama .= $email->nama_depan;
}

if($email->nama_belakang!=''){
$nama .= ' '.$email->nama_belakang;
}
?>
<div class="wrapper">


<table>
  <tr>
    <th colspan="2">Informasi Pribadi</th>
  </tr>
  <tr>
    <td>Cabang :</td><td> <?php echo e($email->cabang); ?></td>
  </tr>
  <tr>
    <td>Nama :</td> <td><?php echo e($nama); ?></td>
  </tr>
  <tr>
    <td>Tempat Kelahiran :</td> <td> <?php echo e($email->tempat_lahir); ?></td>
  </tr>
  <tr>
  <td> Tanggal Lahir :</td>   <td><?php echo e(date("d/m/Y",strtotime($email->tanggal_lahir))); ?></td>
  </tr>
  <tr>
    <td>Jenis Kelamin :</td> <td><?php echo e($email->jk); ?></td>
  </tr>
  <tr>
    <td>Kewarganegaraan :</td> <td><?php echo e($email->kewarganegaraan); ?></td>
  </tr>
  <tr>
    <td>No. KTP : </td><td><?php echo e($email->no_ktp); ?></td>
  </tr>
  <tr>
    <td>No. Paspor : </td><td><?php echo e($email->no_paspor); ?></td>
  </tr>
  <tr>
    <td>Alamat :</td><td> <?php echo e($email->alamat); ?></td>
  </tr>
  <tr>
<td>Kota :</td>
<td><?php echo e($email->kota); ?></td>
  </tr>

  <tr>
    <td>Agama :</td> <td><?php echo e($email->agama); ?></td>
  </tr>
<tr>
  <td>Email :</td> <td> <?php echo e($email->email); ?></td>
</tr>
<tr>
  <td>No HP / WA :</td><td><?php echo e($email->no_telepon); ?></td>
</tr>
</table>
<br>
<table>
  <tr>
    <th colspan="2">Informasi Latar Belakang Pendidikan</th>
  </tr>
  <tr>
    <td>Pendidikan Terakhir</td> <td><?php echo e($email->pendidikan_terakhir); ?></td>
  </tr>
  <tr>
    <td>jurusan</td><td><?php echo e($email->jurusan); ?></td>
  </tr>
  <tr>
    <td>Universitas</td><td><?php echo e($email->ref_universitas); ?></td>
  </tr>
  <tr>
    <td>Bahasa Sehari hari</td><td><?php echo e($email->bahasa_sehari_hari); ?></td>
  </tr>
</table>
<br>
<table>
  <tr>
    <th colspan="2">Informasi Latar Belakang Pekerjaan</th>
  </tr>
  <tr>
    <td>Pekerjaan : </td><td><?php echo e($email->pekerjaan); ?></td>
  </tr>
  <tr>
    <td>Bidang Pekerjaan : </td> <td><?php echo e($email->bidang_pekerjaan); ?></td>
  </tr>
</table>
<br>
<table>
  <tr>
    <th colspan="2">Pemilihan Kursus yang anda minati</th>
  </tr>
  <tr>
    <td>Course :</td> <td><?php echo e($email->nama_paket); ?></td>
  </tr>
  <tr>
    <td>Ielts Module :</td> <td><?php echo e($email->ielts_module); ?></td>
  </tr>
  <tr>
    <td>Kelompok Kelas : </td> <td><?php echo e($email->kelompok_kelas); ?></td>
  </tr>
  <tr>
    <td>Level :</td> <td><?php echo e($email->id_level); ?></td>
  </tr>
  <tr>
    <td colspan="2">Durasi Kelas </td>
  </tr>
  <tr>
<td>Pertemuan :</td> <td><?php echo e($email->jumlah_pertemuan); ?></td>
  </tr>
  <tr>
    <td>Jumlah Jam : </td><td><?php echo e($email->jumlah_jam); ?></td>
  </tr>
  <tr>
    <td>Tujuan Pelatihan : </td> <td><?php echo e($email->tujuan); ?> <?php if(!empty($email->tujuan_lainnya)): ?>
      <?php echo e(' ('.$email->tujuan_lainnya.')'); ?> <?php endif; ?></td>
  </tr>
</table>
<br>
<table>
  <tr>
    <th colspan="2">Informasi Kontak Wali</th>
  </tr>
  <tr>
    <td>Nama Wali</td> <td><?php echo e($email->nama_wali); ?></td>
  </tr>
  <tr>
    <td>Hubungan</td> <td><?php echo e($email->hubungan); ?></td>
  </tr>
  <tr>
    <td>No Hp</td> <td><?php echo e($email->no_telepon_wali); ?></td>
  </tr>
  <tr>
    <td>Email Wali</td> <td><?php echo e($email->email_wali); ?></td>
  </tr>
  <tr>
    <td>Alamat Wali</td> <td><?php echo e($email->alamat_wali); ?></td>
  </tr>
</table>
</div>
<?php /**PATH /home/u823503514/domains/bestpartnereducation.com/public_html/resources/views/email/englishregistration.blade.php ENDPATH**/ ?>